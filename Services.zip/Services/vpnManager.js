import fs from 'fs/promises';
import path from 'path';
import { exec as execProcess, spawn } from 'child_process';
import { promisify } from 'util';
import axios from 'axios';
import log from './logger.js';
import { config } from './loadConfig.js';
 import psTree from 'ps-tree';  

const execPromise = promisify(execProcess);



const VPN_ENABLED = config.vpn?.enable === 1;
const MAX_VPN_RETRIES = config.vpn?.max_retries || 3;
const MAX_EMAILS_PER_VPN = config.vpn?.max_emails_per_vpn || 50;
const FALLBACK_ENABLED = config.vpn?.fallback === 1;
const VPN_CONFIG_DIR = path.resolve(config.vpn?.config_dir || './VpnConfig');
const VPN_USERNAME = config.vpn?.username || '';
const VPN_PASSWORD = config.vpn?.password || '';
const IS_WINDOWS = process.platform === 'win32';
const OPENVPN_PATH = IS_WINDOWS ? 'C:\\Program Files\\OpenVPN\\bin\\openvpn.exe' : '/usr/sbin/openvpn';

let currentVpnIndex = 0;
let vpnConnected = false;
let ovpnProcess = null;

// Select a random VPN config
async function selectVpnConfig() {
  const vpnConfigs = (await fs.readdir(VPN_CONFIG_DIR)).filter(file => file.endsWith('.ovpn'));
  if (vpnConfigs.length === 0) throw new Error('❌ No VPN configuration files found.');

  let newVpnIndex;
  do {
    newVpnIndex = Math.floor(Math.random() * vpnConfigs.length);
  } while (newVpnIndex === currentVpnIndex);

  currentVpnIndex = newVpnIndex;
  return path.join(VPN_CONFIG_DIR, vpnConfigs[currentVpnIndex]);
}

// Prepare VPN auth and log files
async function prepareVpnFiles(vpnConfigPath) {
  const authFilePath = path.join(VPN_CONFIG_DIR, 'auth.txt');
  const logFilePath = path.join(VPN_CONFIG_DIR, 'openvpn.log');

  await fs.writeFile(authFilePath, `${VPN_USERNAME}\n${VPN_PASSWORD}\n`, 'utf8');
  return { authFilePath, logFilePath };
}

// Clean up VPN files
async function cleanupVpnFiles(authFilePath, logFilePath) {
  try {
    if (await fs.access(authFilePath).then(() => true).catch(() => false)) await fs.unlink(authFilePath);
    if (await fs.access(logFilePath).then(() => true).catch(() => false)) await fs.unlink(logFilePath);
  } catch (cleanupError) {
    log.warn(`⚠️ Failed to clean up VPN files: ${cleanupError.message}`);
  }
}

// Check TAP adapter on Windows
async function checkTapAdapter() {
  if (!IS_WINDOWS) return;
  try {
    log.info('🔍 Checking TAP-Windows6 adapter...');
    const { stdout } = await execPromise('netsh interface show interface | findstr "TAP-Windows6"');
    if (!stdout.includes('Connected')) {
      log.warn('⚠️ TAP-Windows6 adapter is disconnected. Enabling...');
      await execPromise('netsh interface set interface "OpenVPN TAP-Windows6" admin=enabled');
      log.info('✅ TAP-Windows6 adapter enabled.');
    } else {
      log.info('✅ TAP-Windows6 adapter is available.');
    }
  } catch (error) {
    log.error(`❌ TAP-Windows6 adapter check failed: ${error.message}`);
    throw new Error('TAP-Windows6 adapter is unavailable');
  }
}

// Connect to VPN
async function connectVpn() {
  try {
    const vpnConfigPath = await selectVpnConfig();
    log.info(`🔗 Connecting to VPN: ${path.basename(vpnConfigPath)}`);

    if (!(await fs.access(OPENVPN_PATH).then(() => true).catch(() => false))) {
      throw new Error(`❌ OpenVPN binary not found at: ${OPENVPN_PATH}`);
    }

    //await checkTapAdapter();
    const { authFilePath, logFilePath } = await prepareVpnFiles(vpnConfigPath);

    const args = [
      '--config', vpnConfigPath,
      '--auth-user-pass', authFilePath,
      '--auth-nocache',
      '--management', '127.0.0.1', '0'  ,      // random free port – we’ll query it later
      '--log', logFilePath,
    ];

    return new Promise((resolve, reject) => {
    ovpnProcess = spawn(OPENVPN_PATH, args, { stdio: ['ignore','pipe','pipe'], windowsHide: true });
      
      ovpnProcess.stdout.on('data', chunk => {
        const line = chunk.toString();
        if (!ovpnProcess.mgmtPort) {
          const m = line.match(/TCP server listening.*127\.0\.0\.1:(\d+)/);
          if (m) ovpnProcess.mgmtPort = m[1];
        }
        if (line.includes('Initialization Sequence Completed')) resolve(true);
      });

      ovpnProcess.on('error', error => {
        log.error(`❌ OpenVPN process error: ${error.message}`);
        ovpnProcess = null;
        reject(error);
      });

      ovpnProcess.on('close', code => {
        log.info(`OpenVPN process closed with code: ${code}`);
        ovpnProcess = null;
        if (code !== 0) reject(new Error(`OpenVPN exited with code ${code}`));
      });

      setTimeout(async () => {
        if (ovpnProcess?.pid) {
          const isStable = await waitForStableNetwork();
          if (isStable) {
            log.info('✅ VPN connected.');
            resolve(true);
          } else {
            reject(new Error('Network stabilization failed'));
          }
        }
      }, 3000);
    }).finally(() => cleanupVpnFiles(authFilePath,));
  } catch (error) {
    log.error(`❌ VPN Connection Failed: ${error.message}`);
    throw error;
  }
}

// Disconnect VPN
async function disconnectVpn() {
  log.info('🔌 Disconnecting VPN...');
  try {
    if (!ovpnProcess?.pid) {
      log.warn('⚠️ No active VPN process to disconnect.');
      return true;
    }
    log.info('📮 Sending management SIGTERM…');
    try {                      // ask politely through the management port first
      await execPromise(`echo "signal SIGTERM" | nc 127.0.0.1 ${ovpnProcess.mgmtPort}`);
    } catch {}

    // wait up to 5 s for clean exit
  const exited = await Promise.race([
    new Promise(r => ovpnProcess.once('exit', r)),
    new Promise(r => setTimeout(r, 5000, false))
  ]);

  if (!exited) {             // escalate
    log.warn('⚠️ Still alive – killing process tree');
    await killProcessTree(ovpnProcess.pid);
  }

  log.info('✅ VPN fully stopped');
    ovpnProcess = null;
    return true;                // <‑‑ stays inside the try‑block
  } catch (error) {
    log.warn(`⚠️ VPN disconnect error: ${error.message}`);
    ovpnProcess = null;
    return true;                // fallback return on error
  }
}

// Flush DNS cache
async function flushDnsCache() {
  try {
    const flushCmd = IS_WINDOWS ? 'ipconfig /flushdns' : 'sudo systemd-resolve --flush-caches';
    await execPromise(flushCmd);
    log.info('✅ DNS cache flushed.');
  } catch (error) {
    log.warn(`⚠️ Failed to flush DNS cache: ${error.message}`);
  }
}

// Get public IP
async function getPublicIP(retries = 5, delay = 3000) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await axios.get('https://api64.ipify.org?format=json', { timeout: 5000 });
      log.info(`✅ Public IP fetched: ${response.data.ip}`);
      return response.data.ip;
    } catch (error) {
      log.warn(`⚠️ IP fetch error (Attempt ${attempt}/${retries}): ${error.message}`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  log.error('❌ Unable to fetch public IP.');
  return null;
}

// Wait for stable network
async function waitForStableNetwork(retries = 5, delay = 3000) {
  log.info('⏳ Waiting for network stability...');
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await axios.get('https://api64.ipify.org?format=json', { timeout: 5000 });
      if (response.data.ip) {
        log.info(`✅ Network is stable. Public IP: ${response.data.ip}`);
        return true;
      }
    } catch (error) {
      log.warn(`⚠️ Network not ready (Attempt ${attempt}/${retries}). Retrying in ${delay / 1000}s...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  log.error('❌ Network failed to stabilize.');
  return false;
}

// Rotate VPN
async function rotateVpn() {
  if (!VPN_ENABLED) {
    log.info('🔵 VPN is disabled. Emails will be sent directly.');
    vpnConnected = true;
    return true;
  }

  log.info('🔄 Rotating VPN connection...');
  let retries = 0;

  while (retries < MAX_VPN_RETRIES) {
    try {
      await disconnectVpn();
            await new Promise(resolve => setTimeout(resolve, 2000));

      await connectVpn();
      await new Promise(resolve => setTimeout(resolve, 2000));
      //await flushDnsCache();

      const isVpnActive = await getPublicIP();
      if (isVpnActive) {
        vpnConnected = true;
        log.info('✅ Successfully rotated VPN.');
        return true;
      } else {
        throw new Error('VPN verification failed.');
      }
    } catch (error) {
      log.error(`❌ VPN rotation failed (Attempt ${retries + 1}/${MAX_VPN_RETRIES}): ${error.message}`);
      retries++;
      await new Promise(resolve => setTimeout(resolve, 3000));
    }
  }

  log.warn('⚠️ All VPN retries failed.');
  vpnConnected = false;

  if (FALLBACK_ENABLED) {
    log.warn('⚠️ Falling back to sending emails without VPN.');
    return true;
  }
  log.error('🚨 No VPN available. Stopping email sending.');
  return false;
}

// Initialize VPN
export async function initializeVpn() {
  if (!VPN_ENABLED) {
    log.info('🔵 VPN is disabled.');
    return;
  }
  const connectSuccess = await rotateVpn();
  if (!connectSuccess) {
    throw new Error('Initial VPN connection failed.');
  }
  vpnConnected = true;
  log.info('✅ VPN initialized.');
}

// Process VPN rotation
export async function processVpn() {
  if (!VPN_ENABLED) return;
  const rotationSuccess = await rotateVpn();
  if (!rotationSuccess) {
    throw new Error('VPN rotation failed.');
  }
  log.info('✅ VPN rotated.');
}

async function killProcessTree(pid) {
  if (IS_WINDOWS) {
    await execPromise(`taskkill /F /T /PID ${pid}`);   // hard‑kill + children
    return;
  }
  // *nix – walk child PIDs first, then parent
  return new Promise(res => {
    psTree(pid, (_, children) => {
      children.forEach(p => { try { process.kill(+p.PID, 'SIGKILL'); } catch {} });
      try { process.kill(pid, 'SIGKILL'); } catch {}
      res();
    });
  });
}