import { Mutex } from 'async-mutex';


export const buffer = new SharedArrayBuffer(24);
export let sharedData = new Int32Array(buffer);
export const emailCounterLock = new Mutex();
export const delayLock = new Mutex();
export const sharedState = {
  get emailsSentUnderCurrentVpn() { return Atomics.load(sharedData, 0); },
  set emailsSentUnderCurrentVpn(v) { Atomics.store(sharedData, 0, v); },
  get emailsSentSinceLastDelay() { return Atomics.load(sharedData, 1); },
  set emailsSentSinceLastDelay(v) { Atomics.store(sharedData, 1, v); },
  get currentProxyIndex() { return Atomics.load(sharedData, 2); },
  set currentProxyIndex(v) { Atomics.store(sharedData, 2, v); },
  get vpnConnected() { return !!Atomics.load(sharedData, 3); },
  set vpnConnected(v) { Atomics.store(sharedData, 3, v ? 1 : 0); },
  get isVpnReady() { return !!Atomics.load(sharedData, 4); },
  set isVpnReady(v) { Atomics.store(sharedData, 4, v ? 1 : 0); },
  get isDelayActive() { return !!Atomics.load(sharedData, 5); },
  set isDelayActive(v) { Atomics.store(sharedData, 5, v ? 1 : 0); },
};