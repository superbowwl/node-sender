import { promises as fs } from 'fs';
import nodemailer from 'nodemailer';
import log from './logger.js';
import {config} from './loadConfig.js';
import { Mutex } from 'async-mutex';



export class NoWorkingSmtpError extends Error {}
export const smtpSelectLock = new Mutex();


const smtpFile = config.Smtp_Config.smtp_file || 'smtp.txt';
let smtpConfigs = [];
let currentIndex = 0;

export async function loadSmtpConfigs() {
    try {
        const data = await fs.readFile(smtpFile, 'utf8');
        smtpConfigs = data
            .split('\n')
            .map(line => line.trim())
            .filter(line => line && !line.startsWith('#'))
            .map(line => {
                const parts = line.split('|');
                if (parts.length !== 6) {
                    console.error(`Invalid line in SMTP file (expected 6 fields): ${line}`);
                    return null;
                }
                const [host, portStr, secureStr, user, pass, limitStr] = parts;
                const port = parseInt(portStr);
                const limit = parseInt(limitStr);
                if (isNaN(port) || isNaN(limit)) {
                    console.error(`Invalid port or limit in line: ${line}`);
                    return null;
                }
                return {
                    host,
                    port,
                    secure: secureStr === '1',
                    auth: { user, pass },
                    limit,
                    counter: 0
                };
            })
            .filter(config => config !== null);
        if (smtpConfigs.length === 0) {
            throw new Error('No valid SMTP configurations found in the file.');
        }
    
//    // console.log('Loaded SMTP configurations:', smtpConfigs.map(c => ({
//         user: c.auth.user,
//         limit: c.limit,
//         counter: c.counter
//     })));
        currentIndex = 0;
    } catch (error) {
        console.error(`Error loading SMTP configurations: ${error.message}`);
        console.log(error.stack);
        throw error;
    }
}

// smtp.js
export async function getNextSmtpConfig() {
    return smtpSelectLock.runExclusive(() => {
     // console.log('Getting next SMTP config. Current index:', currentIndex);
      if (smtpConfigs.length === 0) {
        throw new Error('No SMTP configurations loaded.');
      }
  
      /* ───────────── SINGLE-SMTP MODE ───────────── */
      if (!config.Smtp_Config.multiple_smtp) {
        const smtpConfig = smtpConfigs[0];
        console.log(`Single SMTP mode: ${smtpConfig.auth.user}, counter=${smtpConfig.counter}, limit=${smtpConfig.limit}`);
  
        if (smtpConfig.limit === 0 || smtpConfig.counter < smtpConfig.limit) {
          smtpConfig.counter += 1;          // reserve
          return smtpConfig;
        }
  
        if (config.Smtp_Config.reset_limits === 1) {
          smtpConfig.counter = 1;           // reset then reserve
          return smtpConfig;
        }
  
        throw new Error('SMTP account has reached its email sending limit.');
      }
      const selMode = config.Smtp_Config.selection_mode ?? 1;   // default = 1
  
      /* ───────────── MULTI-SMTP MODE ───────────── */
      if (selMode === 2) {
       /* === SEQUENTIAL ================================================= */
       const smtpConfig = smtpConfigs[currentIndex];
        
       // if current still has quota → keep using it
       if (smtpConfig.limit === 0 || smtpConfig.counter < smtpConfig.limit) {
           smtpConfig.counter += 1;
           return smtpConfig;
       }
        
       // else advance once and start filling the next account
       currentIndex = (currentIndex + 1) % smtpConfigs.length;
}
    
        /* === ROUND-ROBIN SEARCH (shared by both modes) ==================== */
        for (let i = 0; i < smtpConfigs.length; i++) {
         const index      = (currentIndex + i) % smtpConfigs.length;
         const cfg        = smtpConfigs[index];
         if (cfg.limit === 0 || cfg.counter < cfg.limit) {
             cfg.counter += 1;
             currentIndex = selMode === 1        // advance only in round-robin
                 ? (index + 1) % smtpConfigs.length
                 : index;                        // stay on the same one
             return cfg;
         }
        }
  
      /* ───────────── EVERYONE IS FULL ───────────── */
      if (config.Smtp_Config.reset_limits === 1) {
        smtpConfigs.forEach(c => (c.counter = 0));
        currentIndex = 0;
        smtpConfigs[0].counter = 1;         // reserve after reset
        return smtpConfigs[0];
      }
  
      throw new Error('All SMTP accounts have reached their email sending limit.');
    });   // ← lock is automatically released here
  }
  


export async function initializeTransporter() {
    // Get the list of SMTP configurations (assuming it's available via getNextSmtpConfig or config)
    const smtpConfigs = config.Smtp_Configs || []; // Adjust based on actual config structure
    const maxAttempts = smtpConfigs.length || 10; // Fallback to a reasonable number if not available
    let attempts = 0;

    while (attempts < maxAttempts) {
        try {
            // Get the next SMTP configuration
            const selectedSmtpConfig = getNextSmtpConfig();
            if (!selectedSmtpConfig) {
                throw new Error('No SMTP configurations available');
            }

            // Create the transporter with the selected configuration
            const transporter = nodemailer.createTransport({
                timeout: 30000,
                host: selectedSmtpConfig.host,
                port: selectedSmtpConfig.port,
                secure: selectedSmtpConfig.secure,
                auth: selectedSmtpConfig.auth,
                pool: config.Sender_Config.pool === 1 || config.Sender_Config.pool === true,
                maxConnections: (config.Sender_Config.pool === 1 || config.Sender_Config.pool === true) 
                    ? config.Sender_Config.max_connections || 5 
                    : undefined,
                maxMessages: (config.Sender_Config.pool === 1 || config.Sender_Config.pool === true) 
                    ? config.Sender_Config.max_messages || 100 
                    : undefined,
                rateLimit: config.Sender_Config.rate_limit === 1 || config.Sender_Config.rate_limit === true,
            });

            // Verify the transporter
            await transporter.verify();
            log.info(`✅ SMTP verified for ${selectedSmtpConfig.auth.user}`);

            // Return the transporter and its configuration
            return { transporter, selectedSmtpConfig };
        } catch (error) {
            log.error(`❌ SMTP verification failed: ${error.message}`);
            attempts++;
            if (attempts >= maxAttempts) {
                throw new Error('All SMTP configurations failed verification');
            }
            // Continue to the next iteration to try another configuration
        }
    }

    // This line should never be reached due to the throw above, but included for completeness
    throw new Error('Failed to initialize transporter after all attempts');
}