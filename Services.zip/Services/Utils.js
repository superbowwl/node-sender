import { config } from './Config/loadConfig.js';



export function getRandomDelay() {
  if (!config.Sender_Config?.enable_random_delay) return 0;
  return Math.floor(Math.random() * (700 - 200 + 1)) + 300;
}