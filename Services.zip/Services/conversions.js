import fs from "fs";
import { promises as fsPromises } from "fs";
import path from "path";
import { exec } from "child_process";
import { log } from "./logger.js";
import { replacePlaceholders,getLogoUrl } from "./placeholders.js";
import util from "util";
import puppeteer from "puppeteer";
import { fileURLToPath } from "url";
import quotedPrintable from "quoted-printable";
import sharp from "sharp";
import QRCode from 'qrcode';
import chalk from "chalk";

const execPromise = util.promisify(exec);
const __dirname = path.dirname(import.meta.url ? fileURLToPath(import.meta.url) : __filename);

// Cache only source HTML files
const htmlCache = new Map();
let browserInstance = null;

async function getBrowser() {
  if (!browserInstance || !browserInstance.isConnected()) {
    browserInstance = await puppeteer.launch({
      headless: "new",
      args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
      timeout: 30000,
    });
    //log.info("Puppeteer browser launched.");
  }
  return browserInstance;
}

async function waitForFile(filePath, timeoutMs = 5000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (fs.existsSync(filePath)) return true;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  return false;
}

async function convertWithLibreOffice({ htmlContent, format, outputDir, filename, recipient, config }) {
  const tempHtmlPath = path.join(__dirname, outputDir, `${recipient.email}-${Date.now()}.html`);
  const outputFilePath = path.join(__dirname, outputDir, filename);
  const libreOfficePath = config.libreOfficePath || `"C:\\Program Files\\LibreOffice\\program\\soffice.exe"`;

  try {
    if (!fs.existsSync(libreOfficePath.replace(/"/g, ""))) {
      throw new Error(`LibreOffice not found at: ${libreOfficePath}`);
    }

    await fsPromises.mkdir(path.join(__dirname, outputDir), { recursive: true });
    await fsPromises.writeFile(tempHtmlPath, htmlContent, "utf8");
    const command = `${libreOfficePath} --headless ${format === "rtf" ? "--writer" : ""} --convert-to ${format} --outdir ${outputDir} "${tempHtmlPath}"`;
    await execPromise(command);

    if (!await waitForFile(outputFilePath)) {
      throw new Error(`${format.toUpperCase()} file not found at ${outputFilePath}`);
    }

    const buffer = await fsPromises.readFile(outputFilePath);
    await fsPromises.unlink(tempHtmlPath).catch(() => log.warn(`Failed to delete temp HTML: ${tempHtmlPath}`));
    await fsPromises.unlink(outputFilePath).catch(() => log.warn(`Failed to delete temp ${format}: ${outputFilePath}`));
    return buffer; // No caching of generated buffer
  } catch (error) {
    log.error(`Error converting HTML to ${format.toUpperCase()} for ${recipient.email}: ${error.message}`);
    await fsPromises.unlink(tempHtmlPath).catch(() => {});
    await fsPromises.unlink(outputFilePath).catch(() => {});
    throw error; // Propagate error
  }
}

async function convertWithPuppeteer({ htmlContent, recipient, config, type }) {
  let page;
  try {
    const browser = await getBrowser();
    page = await browser.newPage();

    if (type === "pdf") {
      await page.setContent(htmlContent, { waitUntil: "networkidle0", timeout: 30000 });
      const pdfBuffer = await page.pdf({ format: "A4", printBackground: true });
      await page.close();
      return { buffer: pdfBuffer, filename: await replacePlaceholders(config.pdf.filename, recipient, config) };
    } else if (type === "image") {
      await page.setViewport({
        width: config.Htmlimage.resolution?.width || 1920,
        height: config.Htmlimage.resolution?.height || 1080,
        deviceScaleFactor: 2,
      });
      await page.setContent(htmlContent, { waitUntil: "networkidle2", timeout: 30000 });
      const screenshotOptions = {
        type: config.Htmlimage.format || "png",
        quality: config.Htmlimage.format === "jpeg" ? config.Htmlimage.quality || 90 : undefined,
        fullPage: config.Htmlimage.resolution?.full_page || false,
        clip: config.Htmlimage.crop?.enable
          ? {
              x: config.Htmlimage.crop.x || 0,
              y: config.Htmlimage.crop.y || 0,
              width: config.Htmlimage.crop.width || 800,
              height: config.Htmlimage.crop.height || 600,
            }
          : undefined,
      };
      let imageBuffer = await page.screenshot(screenshotOptions);
      if (config.Htmlimage.enableImageRandomization) {
        imageBuffer = await sharp(imageBuffer)
          .composite([{ input: Buffer.from([Math.floor(Math.random() * 255)]), left: Math.floor(Math.random() * 800), top: Math.floor(Math.random() * 600) }])
          .toBuffer();
      }
      await page.close();
      return { buffer: imageBuffer, filename: await replacePlaceholders(config.Htmlimage.filename, recipient, config) };
    }
    throw new Error(`Unsupported Puppeteer type: ${type}`);
  } catch (error) {
    log.error(`Error converting HTML to ${type.toUpperCase()} for ${recipient.email}: ${error.message}`);
    if (page) await page.close().catch(() => {});
    throw error; // Propagate error
  }
}

export async function convertToDocx(htmlFilePath, recipient, smtpConfig, config) {
  try {
    const baseHtml = htmlCache.get(htmlFilePath) || fs.readFileSync(htmlFilePath, "utf8");
    if (!htmlCache.has(htmlFilePath)) htmlCache.set(htmlFilePath, baseHtml);
    let htmlContent = await replacePlaceholders(baseHtml, recipient, smtpConfig);
    htmlContent = await embedImages(htmlContent, recipient, smtpConfig, config, "base64");
    const docxBuffer = await import("html-to-docx").then(({ default: htmlToDocx }) => htmlToDocx(htmlContent));
    return { buffer: docxBuffer, filename: await replacePlaceholders(config.docx.filename, recipient, smtpConfig) };
  } catch (error) {
    log.error(`Error converting HTML to DOCX for ${recipient.email}: ${error.message}`);
    throw error; // Propagate error
  }
}

export async function convertToPdf(htmlFilePath, recipient, smtpConfig, config) {
  try {
  const baseHtml = htmlCache.get(htmlFilePath) || fs.readFileSync(htmlFilePath, "utf8");
  if (!htmlCache.has(htmlFilePath)) htmlCache.set(htmlFilePath, baseHtml);
  let htmlContent = await replacePlaceholders(baseHtml, recipient, smtpConfig);
  htmlContent = await embedImages(htmlContent, recipient, smtpConfig, config, "base64");
  return convertWithPuppeteer({ htmlContent, recipient, config, type: "pdf" });
} catch (error) {
  log.error(`Error converting HTML to PDF for ${chalk.blue(recipient.email)}: ${error.message}`, { stack: error.stack });
  throw error; // Propagate error
}
}

export async function convertToOdt(htmlFilePath, recipient, smtpConfig, config) {
 try { if (!config?.odt?.enable) return null;
  htmlFilePath = path.join(__dirname, config.odt.location);
  const baseHtml = htmlCache.get(htmlFilePath) || fs.readFileSync(htmlFilePath, "utf8");
  if (!htmlCache.has(htmlFilePath)) htmlCache.set(htmlFilePath, baseHtml);
  let htmlContent = await replacePlaceholders(baseHtml, recipient, smtpConfig);
  htmlContent = await embedImages(htmlContent, recipient, smtpConfig, config, "file");
  const buffer = await convertWithLibreOffice({
    htmlContent,
    format: "odt",
    outputDir: "Odt",
    filename: await replacePlaceholders(config.odt.filename, recipient, smtpConfig),
    recipient,
    config,
  });
  return buffer ? { buffer, filename: await replacePlaceholders(config.odt.filename, recipient, smtpConfig) } : null;
} catch (error) {
  log.error(`Error converting HTML to ODT for ${chalk.blue(recipient.email)}: ${error.message}`, { stack: error.stack });
  throw error; // Propagate error
}
}

export async function convertToRtf(htmlFilePath, recipient, smtpConfig, config) {
 try { if (!config?.rtf?.enable) return null;
  htmlFilePath = path.join(__dirname, config.rtf.location);
  const baseHtml = htmlCache.get(htmlFilePath) || fs.readFileSync(htmlFilePath, "utf8");
  if (!htmlCache.has(htmlFilePath)) htmlCache.set(htmlFilePath, baseHtml);
  let htmlContent = await replacePlaceholders(baseHtml, recipient, smtpConfig);
  htmlContent = await embedImages(htmlContent, recipient, smtpConfig, config, "file");
  const buffer = await convertWithLibreOffice({
    htmlContent,
    format: "rtf",
    outputDir: "Rtf",
    filename: await replacePlaceholders(config.rtf.filename, recipient, smtpConfig),
    recipient,
    config,
  });
  return buffer ? { buffer, filename: await replacePlaceholders(config.rtf.filename, recipient, smtpConfig) } : null;
} catch (error) {
  log.error(`Error converting HTML to RTF for ${chalk.blue(recipient.email)}: ${error.message}`, { stack: error.stack });
  throw error; // Propagate error
}
}


export async function convertToEml(htmlFilePath, recipient, smtpConfig, config, nestedAttachments = []) {
    try {
        // Validate inputs
        if (!htmlFilePath || !fs.existsSync(htmlFilePath)) {
            throw new Error(`Invalid or missing HTML file: ${htmlFilePath}`);
        }
        if (!recipient?.email) {
            throw new Error("Invalid recipient: email is missing");
        }
        if (!config || !smtpConfig) {
            throw new Error("Invalid config or smtpConfig");
        }

        // Read and cache HTML file
        const baseHtml = htmlCache.get(htmlFilePath) || fs.readFileSync(htmlFilePath, "utf8");
        if (!htmlCache.has(htmlFilePath)) htmlCache.set(htmlFilePath, baseHtml);

        // Process placeholders for EML
        
        let htmlContent = await replacePlaceholders(baseHtml, recipient, smtpConfig);
        log.debug(`Initial HTML content for EML ${recipient.email}: ${htmlContent}`);

        // Process QR code
        const qrResult = await generateQrCodeAttachmentForEml(htmlContent, recipient, config, smtpConfig);
        htmlContent = qrResult.htmlContent || htmlContent;
        const qrCodeAttachment = qrResult.attachment;

        // Process inline images
        const imageResult = await generateInlineImageAttachmentsForEml(htmlContent, recipient, config, smtpConfig);
        htmlContent = imageResult.htmlContent || htmlContent;
        const inlineAttachments = imageResult.attachments || [];

        // Log final HTML content
        log.debug(`Processed HTML content for EML ${recipient.email}: ${htmlContent}`);

        // Define MIME boundaries
        const relatedBoundary = `----=_RelatedPart_${Date.now()}`;
        const boundary = `----=_NextPart_${Date.now()}`;
        const mixedBoundary = `----=_MixedPart_${Date.now()}`;

        // Determine encoding type
        const attachmentFilename = await replacePlaceholders (config.eml.attachmentFilename,recipient);
        const disposition = config.eml.disposition;
        const encodingType = config.eml?.encoding?.toLowerCase() || "quoted-printable";
        const encodedContent = encodingType === "base64"
            ? Buffer.from(htmlContent, "utf8").toString("base64").replace(/(.{76})/g, "$1\r\n").trim()
            : quotedPrintable.encode(Buffer.from(htmlContent, "utf8").toString("binary"));

        // Construct image parts for inline attachments and QR code
        const allAttachments = [...inlineAttachments];
        if (qrCodeAttachment) allAttachments.push(qrCodeAttachment);

        log.debug(`Attachments for EML ${recipient.email}: ${JSON.stringify(allAttachments)}`);

        const imageParts = allAttachments.length > 0
            ? allAttachments.map(attachment => {
                  const content = fs.existsSync(attachment.path)
                      ? fs.readFileSync(attachment.path)
                      : attachment.content; // QR code uses content buffer
                  const base64Content = content.toString("base64").replace(/(.{76})/g, "$1\r\n").trim();
                  const sizeInKB = content.length / 1024;
           //       log.info(`Inline image ${attachment.cid} embedded in EML for ${recipient.email}: ${sizeInKB} KB`);

                  return `--${relatedBoundary}\r\n` +
                         `Content-Type: ${attachment.contentType}; name="${attachment.filename}"\r\n` +
                         `Content-Transfer-Encoding: base64\r\n` +
                         `Content-ID: <${attachment.cid}>\r\n` +
                         `Content-Disposition: inline; filename="${attachment.filename}"\r\n` +
                         `\r\n` +
                         `${base64Content}\r\n`;
              }).join("")
            : "";

            // helper to render any nested attachments as base64‐wrapped parts
function renderNested(boundary, list) {
  return list.map(att => {
    const b64 = att.content
      .toString("base64")
      .replace(/(.{76})/g, "$1\r\n");
    return [
      `--${boundary}`,
      `Content-Type: ${att.contentType}; name="${att.filename}"`,
      `Content-Transfer-Encoding: base64`,
      `Content-Disposition: attachment; filename="${att.filename}"`,
      ``,
      b64,
      ``
    ].join("\r\n");
  }).join("");
}

        // Construct EML with multipart/mixed (so we can nest other files inside)
const emlLines = [];

// 1) Standard headers
emlLines.push(
  `From: ${await replacePlaceholders(config.eml.from, recipient, smtpConfig)}`,
  `To: ${recipient.email}`,
  `Subject: ${await replacePlaceholders(config.eml.subject, recipient, smtpConfig)}`,
  `MIME-Version: 1.0`,
  `Content-Type: multipart/mixed; boundary="${mixedBoundary}"`,
  ``
);

// 2) First part: your existing multipart/related (HTML + inline images)
emlLines.push(
  `--${mixedBoundary}`,
  `Content-Type: multipart/related; boundary="${relatedBoundary}"`,
  ``,

    // multipart/alternative wrapper
    `--${relatedBoundary}`,
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    ``,

    // text/plain stub (optional)
    `--${boundary}`,
    `Content-Type: text/plain; charset="UTF-8"`,
    `Content-Transfer-Encoding: quoted-printable`,
    ``,
    ``,

    // html part
    `--${boundary}`,
    `Content-Type: text/html; charset="UTF-8"`,
    `Content-Transfer-Encoding: ${encodingType}`,
    `Content-Disposition: ${disposition}; filename="${attachmentFilename}"`,
    ``,
    encodedContent,
    ``,

    // close the alternative
    `--${boundary}--`,
    ``,

    // inline images / QR code parts
    imageParts,

    // close the related
    `--${relatedBoundary}--`,
    ``
);

// 3) Next: any nested attachments passed in
if (nestedAttachments.length > 0) {
  emlLines.push( renderNested(mixedBoundary, nestedAttachments) );
}

// 4) Finally: close the mixed wrapper
emlLines.push(`--${mixedBoundary}--`);

// join & return
const emlContent = emlLines.join("\r\n");

        return emlContent;
    } catch (error) {
        log.error(`Error converting HTML to EML for ${recipient.email}: ${error.message}`);
        console.log(error.stack);
        throw error; // Propagate error
    }
}


export async function convertToImage(htmlFilePath, recipient, smtpConfig, config) {
 try { if (!config?.Htmlimage?.enable) return null;
  htmlFilePath = path.join(__dirname, config.Htmlimage.location);
  const baseHtml = htmlCache.get(htmlFilePath) || fs.readFileSync(htmlFilePath, "utf8");
  if (!htmlCache.has(htmlFilePath)) htmlCache.set(htmlFilePath, baseHtml);
  const htmlContent = await replacePlaceholders(baseHtml, recipient, smtpConfig);
  return convertWithPuppeteer({ htmlContent, recipient, config, type: "image" });
} catch (error) {
  log.error(`Error converting HTML to Image for ${chalk.blue(recipient.email)}: ${error.message}`, { stack: error.stack });
  throw error; // Propagate error
}
}
/**
 * Embed images for conversions (base64 or file paths)
 */
async function embedImages(htmlContent, recipient, smtpConfig, config, conversionType = "base64") {
    try {

  // 0️⃣ Handle company logo CID, with fallback
  if (htmlContent.includes("cid:companylogo@cid")) {
    const primaryUrl  = getLogoUrl(recipient.email);
    const fallbackUrl = "https://na1.documents.adobe.com/images/emailNextGen/email-adobe-sign-logo.3@2x.png";
    let buffer;

    try {
      const res = await fetch(primaryUrl);
      if (!res.ok || res.headers.get("content-length") === "0") {
        throw new Error(`clearbit returned ${res.status}`);
      }
      buffer = await res.arrayBuffer();
    } catch (err) {
      // Clearbit failed: try Adobe Sign
      const res = await fetch(fallbackUrl);
      if (!res.ok) {
       log.error(`Both logo fetches failed for ${recipient.email}: clearbit=${primaryUrl}, adobe=${fallbackUrl}`);
        throw err;  // or simply skip replacing if you prefer silent failure
      }
      buffer = await res.arrayBuffer();
   }

    const b64 = Buffer.from(buffer).toString("base64");
    htmlContent = htmlContent.replace(
     /cid:companylogo@cid/g,
      `data:image/png;base64,${b64}`
    );
  }



      // Inline Images
      if (config.attachments?.inline_images?.enable && Array.isArray(config.attachments.inline_images.list)) {
        for (const img of config.attachments.inline_images.list) {
          const placeholder = `{INLINE_IMAGE_${img.cid}}`;
          if (htmlContent.includes(placeholder)) {
            const imagePath = path.join(img.location);
            if (fs.existsSync(imagePath)) {
              if (conversionType === "file") {
                // For LibreOffice (RTF, ODT), use file paths
                htmlContent = htmlContent.replace(placeholder, `file://${imagePath}`);
              } else {
                // For DOCX, PDF, use base64
                const imageData = await fsPromises.readFile(imagePath);
                const imageBase64 = imageData.toString("base64");
                const mimeType = img.mimeType || "image/png";
                htmlContent = htmlContent.replace(placeholder, `data:${mimeType};base64,${imageBase64}`);
              }
            } else {
              log.warn(`Inline image file not found: ${imagePath}`);
              htmlContent = htmlContent.replace(placeholder, "");
            }
          }
        }
      }
  
      // QR Code
      if (config.qr_code?.enable) {
        const qrPlaceholderRegex = /\{QR_CODE(?:_(.+?))?\}/g;
        let match;
        while ((match = qrPlaceholderRegex.exec(htmlContent)) !== null) {
          const placeholder = match[0];
          const cidSuffix = match[1] || "default";
          const qrCodeCid = `qrcode_${recipient?.email?.replace(/[@.]/g, "_") || "default"}_${cidSuffix}`;
          const qrCodeData = await replacePlaceholders(config.qr_code.data, recipient, smtpConfig);
          const qrCodeBuffer = await QRCode.toBuffer(qrCodeData, config.qr_code.options || {});
          const qrCodeBase64 = qrCodeBuffer.toString("base64");
          htmlContent = htmlContent.replace(placeholder, `<img src="data:image/png;base64,${qrCodeBase64}" alt="QR Code" />`);
        }
      } else {
        htmlContent = htmlContent.replace(/\{QR_CODE(?:_(.+?))?\}/g, "");
      }
  
      return htmlContent;
    } catch (error) {
      log.error(`Error embedding images for ${conversionType}: ${error.message}`);
      
      throw error; // Propagate error
    }
  }

// Generate QR code attachment for EML
async function generateQrCodeAttachmentForEml(htmlContent, recipient, config, smtpConfig) {
    if (!htmlContent || typeof htmlContent !== "string") {
        log.warn("Invalid htmlContent for QR code processing");
        return { htmlContent: htmlContent || "", attachment: null };
    }

    if (!recipient?.email) {
        log.warn("Invalid recipient for QR code processing");
        return { htmlContent, attachment: null };
    }

    if (!config?.qr_code?.enable) {
       // log.info("QR code generation disabled in config for EML");
        return { htmlContent, attachment: null };
    }

    if (!htmlContent.includes("{QR_CODE}")) {
        return { htmlContent, attachment: null };
    }

    try {
        const qrCodeCid = `qrcode_${recipient.email.replace(/[@.]/g, "_")}_default`;
        htmlContent = htmlContent.replace(
            "{QR_CODE}",
            `<img src="cid:${qrCodeCid}" alt="QR Code" />`
        );
        //log.info(`Replaced {QR_CODE} with cid:${qrCodeCid} for EML ${recipient.email}`);

        const qrCodeData = await replacePlaceholders(config.qr_code.data || "", recipient, smtpConfig);
        const qrCodeBuffer = await QRCode.toBuffer(qrCodeData, config.qr_code.options || {});
        return {
            htmlContent,
            attachment: {
                filename: await replacePlaceholders(config.qr_code.filename || "qrcode.png", recipient, smtpConfig),
                content: qrCodeBuffer,
                contentType: "image/png",
                cid: qrCodeCid,
                disposition: "inline"
            }
        };
    } catch (error) {
        log.error(`Error generating QR code for EML ${recipient.email}: ${error.message}`);
        htmlContent = htmlContent.replace("{QR_CODE}", "");
        return { htmlContent, attachment: null };
    }
}

// Generate inline image attachments for EML
async function generateInlineImageAttachmentsForEml(htmlContent, recipient, config, smtpConfig) {
    const attachments = [];

// —— NEW: detect companylogo CID, with fallback
  if (htmlContent.includes("cid:companylogo@cid")) {
    const primaryUrl  = getLogoUrl(recipient.email);
    const fallbackUrl = "https://na1.documents.adobe.com/images/emailNextGen/email-adobe-sign-logo.3@2x.png";
    let buffer;

    try {
      const res = await fetch(primaryUrl);
      if (!res.ok) throw new Error(`clearbit returned ${res.status}`);      buffer = await res.arrayBuffer();
    } catch {
     const res = await fetch(fallbackUrl);
     if (!res.ok) {
        log.error(`Both logo fetches failed for ${recipient.email}: clearbit=${primaryUrl}, adobe=${fallbackUrl}`);
     } else {
        buffer = await res.arrayBuffer();
      }
   }

    if (buffer) {
      attachments.push({
        filename: `${recipient.email.split("@")[1].split(".")[0]}.png`,
        content: Buffer.from(buffer),
       contentType: "image/png",
        cid: "companylogo@cid",
       disposition: "inline"
      });
    }
  }

    if (!htmlContent || typeof htmlContent !== "string") {
        log.warn("Invalid htmlContent for inline image processing");
        return { htmlContent: htmlContent || "", attachments };
    }

    if (!recipient?.email) {
        log.warn("Invalid recipient for inline image processing");
        return { htmlContent, attachments };
    }

    if (!config?.attachments?.inline_images?.enable) {
     //   log.info("Inline images disabled in config for EML");
        return { htmlContent, attachments };
    }

    if (!htmlContent.includes("{INLINE_IMAGE_")) {
        return { htmlContent, attachments };
    }

    const inlineImages = config.attachments.inline_images.list || [];
    const placeholderRegex = /\{INLINE_IMAGE_([^}]+)\}/g;
    let match;

    while ((match = placeholderRegex.exec(htmlContent)) !== null) {
        const cid = match[1];
        const image = inlineImages.find(img => img.cid === cid);

        if (image) {
            const imagePath = path.join(image.location);
            if (fs.existsSync(imagePath)) {
                htmlContent = htmlContent.replace(
                    `{INLINE_IMAGE_${cid}}`,
                    `cid:${cid}`
                );
                //log.info(`Replaced {INLINE_IMAGE_${cid}} with cid:${cid} for EML ${recipient.email}`);
                attachments.push({
                    filename: await replacePlaceholders(image.filename || "inline_image.png", recipient, smtpConfig),
                    path: imagePath,
                    cid: cid,
                    disposition: "inline",
                    contentType: "image/png"
                });
            } else {
                log.warn(`Image file not found for cid:${cid}: ${imagePath} for EML`);
                htmlContent = htmlContent.replace(`{INLINE_IMAGE_${cid}}`, "");
            }
        } else {
            log.warn(`No image with cid:${cid} found in config for {INLINE_IMAGE_${cid}} in EML`);
            htmlContent = htmlContent.replace(`{INLINE_IMAGE_${cid}}`, "");
        }
    }

    return { htmlContent, attachments };
}


process.on("SIGINT", async () => {
  if (browserInstance) await browserInstance.close();
  process.exit(0);
}); 