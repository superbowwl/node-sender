import { OpenAI } from 'openai';
import fs from 'fs/promises';
import log from './logger.js';
import { config } from './loadConfig.js';

// Initialize OpenAI client
let openaiClient = null;
const initializeAIClient = async () => {
  if (!openaiClient) {
    const keyFile = config.ai?.keyFile;
    if (!keyFile) {
      log.error('❌ OpenAI key file not specified in config.ai.keyFile');
      throw new Error('Missing OpenAI key file path');
    }

    try {
      const apiKey = (await fs.readFile(keyFile, 'utf8')).trim();
      if (!apiKey) {
        log.error('❌ OpenAI API key is empty in file: ' + keyFile);
        throw new Error('Empty OpenAI API key');
      }
      openaiClient = new OpenAI({ apiKey });
      log.info('✅ OpenAI client initialized from key file: ' + keyFile);
    } catch (error) {
      log.error(`❌ Failed to read OpenAI key from ${keyFile}: ${error.message}`);
      throw error;
    }
  }
  return openaiClient;
};

// Cache for generated templates and subjects
const templateCache = [];
const subjectCache = [];

// Generate email template using AI
async function generateEmailTemplate() {
  try {
    const client = await initializeAIClient();
    const prompt = config.ai?.templatePrompt || `
      Generate a professional HTML email template for a business notification (e.g., e-statement, invoice, or account update).
      Include placeholders like {FAKENAME}, {FROMDOMAIN}, {DATE}, and {COMPANY} for dynamic replacement.
      Use a clean, modern design with a header, body, and footer.
      Keep the tone formal and the length under 300 words.
      Return only the HTML content, no explanations.
    `;

    const response = await client.chat.completions.create({
      model: config.ai?.model || 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: config.ai?.maxTemplateTokens || 500,
      temperature: config.ai?.temperature || 0.7,
    });

    const template = response.choices[0].message.content.trim();
    templateCache.push(template);
    log.info('✅ Generated AI email template');
    return template;
  } catch (error) {
    log.error(`❌ Failed to generate email template: ${error.message}`);
    throw error;
  }
}

// Generate email subject using AI
async function generateEmailSubject() {
  try {
    const client = await initializeAIClient();
    const prompt = config.ai?.subjectPrompt || `
      Generate a concise, professional email subject line for a business notification (e.g., e-statement, invoice, or account update).
      Include placeholders like {FAKENAME} or {COMPANY} if appropriate.
      Keep it under 60 characters and formal in tone.
      Return only the subject line, no explanations.
    `;

    const response = await client.chat.completions.create({
      model: config.ai?.model || 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: config.ai?.maxSubjectTokens || 50,
      temperature: config.ai?.temperature || 0.7,
    });

    const subject = response.choices[0].message.content.trim();
    subjectCache.push(subject);
    log.info('✅ Generated AI email subject');
    return subject;
  } catch (error) {
    log.error(`❌ Failed to generate email subject: ${error.message}`);
    throw error;
  }
}

// Get next email template (AI only)
export async function getNextTemplate() {
  if (templateCache.length > 0) {
    return templateCache.shift(); // Use cached AI template
  }
  return await generateEmailTemplate();
}

// Get next email subject (AI only)
export async function getNextSubject() {
  if (subjectCache.length > 0) {
    return subjectCache.shift(); // Use cached AI subject
  }
  return await generateEmailSubject();
}

// Pre-generate templates and subjects for bulk sending
export async function preGenerateContent(count = 10) {
  try {
    log.info(`🛠️ Pre-generating ${count} AI templates and subjects`);
    const templatePromises = Array.from({ length: count }, generateEmailTemplate);
    const subjectPromises = Array.from({ length: count }, generateEmailSubject);
    await Promise.all([...templatePromises, ...subjectPromises]);
    log.info(`✅ Pre-generated ${count} templates and subjects`);
  } catch (error) {
    log.error(`❌ Failed to pre-generate content: ${error.message}`);
    throw error;
  }
}

export default {
  getNextTemplate,
  getNextSubject,
  preGenerateContent,
};