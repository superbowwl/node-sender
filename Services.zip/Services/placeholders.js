import fs from 'fs';
import { promises as fsPromises } from "fs"
import yaml from 'js-yaml';
import crypto from 'crypto';
import { faker } from '@faker-js/faker';
import { Buffer } from 'buffer';
import log from './logger.js';
import { fileURLToPath } from "url";
import { dirname } from "path";
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * ✅ Load Config from `config.yml`
 */
const loadConfig = () => {
    try {
        return yaml.load(fs.readFileSync("config.yml", "utf8")) || {};
    } catch (error) {
        log.error("❌ Error loading config.yml:", error);
        return {};
    }
};

// ✅ Read settings from config file
const config = loadConfig();


const loadLinks = () => {
    try {
        if (!config.links.enable) {
           // log.warn("🔴 Link loading is DISABLED. No links will be used.");
            return [];
        }

        // ✅ If using a file, read links from file_path
        if (config.links.use_file) {
            const filePath = config.links.file_path;
            if (!fs.existsSync(filePath)) {
                log.warn(`⚠️ Links file '${filePath}' not found! Using fallback link.`);
                return [config.links.fallback_link];
            }

            const links = fs.readFileSync(filePath, "utf8")
                .split("\n")
                .map(line => line.trim())
                .filter(link => link.length > 0 && link.startsWith("http")); // Ensure valid URLs

            return links.length > 0 ? [...new Set(links)] : [config.links.fallback_link];
        }

        // ✅ If not using a file, return predefined links from config.yml
        if (config.links.predefined_links.length > 0) {
            return config.links.predefined_links;
        }

        return [config.links.fallback_link];

    } catch (error) {
        log.error("❌ Error loading links:", error.message);
        return [config.links.fallback_link];
    }
};

// ✅ Load links into a constant
const LINKS = loadLinks();

if (config.links.enable && LINKS.length > 0) {
    log.info(`🔗 Loaded ${LINKS.length} links.`);
}
// Generate random numbers of specified length
const getRandomNumbers = (length) => {
    return Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');
};

// Generate random lowercase characters of specified length
const getRandomLowercase = (length) => {
    const chars = "abcdefghijklmnopqrstuvwxyz";
    return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
};

// Generate random uppercase characters of specified length
const getRandomUppercase = (length) => {
    return getRandomLowercase(length).toUpperCase();
};

// Generate a censored version of the email (e.g., `g****@gmail.com`)
const censorEmail = (email) => {
    const [name, domain] = email.split("@");
    if (!name || !domain) return email;
    return `${name[0]}****@${domain}`;
};

// Extract domain and company name from email
const extractDomain = (email) => {
    const parts = email.split("@");
    return parts.length > 1 ? parts[1] : email;
};

// Extract domain name without extension
const extractDomainWithoutExtension = (email) => {
    const domain = extractDomain(email);
    return domain.split(".")[0]; // Take first part before `.com`, `.net`, etc.
};

// Convert email to Base64 encoding
const encodeBase64 = (text) => Buffer.from(text).toString("base64");

// Get current date and time
function getDateTime(type) {
    const now = new Date();
    if (type === "TOMORROW") now.setDate(now.getDate() + 1);
    return now.toLocaleDateString("en-US");

};

// ✅ URL Encoding Function (Encodes every character)
const encodeUrl = (text) => {
    return text
        .split("")
        .map(char => {
            const hex = char.charCodeAt(0).toString(16).toUpperCase();
            return `%${hex.padStart(2, "0")}`;
        })
        .join("");
};


// Convert text to Hex encoding
const encodeHex = (text) => Buffer.from(text).toString("hex");

// Convert text to HTML character entities (e.g., 'a' → '&#x61;')
const encodeHtmlEntity = (text) => {
    return text
        .split("")
        .map(char => {
            const hex = char.charCodeAt(0).toString(16).toUpperCase();
            return `&#x${hex.padStart(2, "0")};`;
        })
        .join("");
};


// Extract username from email
const extractUsername = (email) => email.split("@")[0];


// Fetch logo URL from email domain
export const getLogoUrl = (email) => {
    const domain = extractDomain(email);
    return `https://logo.clearbit.com/${domain}?size=400&format=png`;
};



// Generate a random string of given size
const getRandomString = (size, upperCase = false) => {
    const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    let randomString = Array.from({ length: size }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return upperCase ? randomString.toUpperCase() : randomString;
};

function capitalizeFirstLetter(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

const generateUUID = () => crypto.randomUUID();





export async function replacePlaceholders(template, recipient, smtpConfig,) {
        if (!template || typeof template !== "string") {
       // log.error("❌ Error: Template content is missing or not a valid string. Returning an empty string.");
        return ""; // Prevent further errors
    }
    
const currentDate = new Date();
const currentTime = currentDate.toLocaleTimeString("en-US");

const logoTag =  `cid:companylogo@cid`;

    return template
        // ✅ Basic Replacements (Ensures all occurrences are replaced)
        .replace (/\{UUID\}/g, generateUUID())  // ✅ New UUID Support
        .replace(/\{RECIPIENT_NAME\}/g, recipient?.name || "User")
        .replace(/\{RECIPIENT_EMAIL\}/g, recipient?.email || "no-email@example.com")
        .replace(/\{SMTP_USER\}/g, smtpConfig?.auth?.user || "unknown-user")
       // .replace(/\{FROMDOMAIN\}/g, getFromDomain(fromMail))
        .replace(/\{COMPANY_NAME\}/g, recipient?.company || "{USERNAME}")
        .replace(/\{CURRENT_DATE\}/g, currentDate.toLocaleDateString())
        .replace(/\{CURRENT_TIME\}/g, currentDate.toLocaleTimeString("en-US"))
        .replace(/\{EMAIL\}/g, recipient?.email || "")
        .replace(/\{EMAIL64\}/g, encodeBase64(recipient?.email || ""))
        .replace(/\{EMAILCENSORED\}/g, censorEmail(recipient?.email || ""))
        .replace(/\{USERNAME\}/g, extractUsername(recipient?.email || ""))
        .replace(/\{DOMAINFULL\}/g, extractDomain(recipient?.email || ""))
        .replace(/\{DOMAINEMAIL\}/g, extractDomainWithoutExtension(recipient?.email || ""))
        .replace(/\{LOGO\}/g, logoTag)
        .replace(/\{LINK\}/g, LINKS[Math.floor(Math.random() * LINKS.length)] || config.links.fallback_link)
        .replace(/\{FAKENAME\}/g, faker.person.fullName())
        .replace(/\{FIRSTNAME\}/g, faker.person.firstName())
        .replace(/\{LASTNAME\}/g, faker.person.lastName())

        // ✅ Randomized Numeric & Character Placeholders
        .replace(/\{NUMBER(\d+)\}/g, (_, num) => getRandomNumbers(Number(num)))
        .replace(/\{char(\d+)\}/g, (_, num) => getRandomLowercase(Number(num)))
        .replace(/\{CHAR(\d+)\}/g, (_, num) => getRandomUppercase(Number(num)))

        // ✅ Random Strings
        .replace(/\{randstring\}/g, getRandomString(10))
        .replace(/\{RANDSTRING\}/g, getRandomString(10, true))
        .replace(/\{RANDOMSTRING25\}/g, getRandomString(25)) // Added for 25 chars
        .replace(/\{RANDOMSTRING100\}/g, getRandomString(100))

        // ✅ Date & Time
        .replace(/\{DATE\}/g, getDateTime("DATE"))
        .replace(/\{TOMORROW\}/g, getDateTime("TOMORROW"))
        .replace(/\{TIME\}/g, new Date().toLocaleTimeString("en-US"))

        // ✅ Randomized Fake Data
        .replace(/\{COUNTRY\}/g, faker.location.country())
        .replace(/\{IP\}/g, faker.internet.ip())
        //.replace(/\{OS\}/g, faker.system.os()) // Uncomment if needed
        .replace(/\{BROWSER\}/g, faker.internet.userAgent())

        // ✅ Link Placeholders
        .replace(/\{LINK\}/g, LINKS[Math.floor(Math.random() * LINKS.length)]) 
        .replace(/\{FAKENAME\}/g, faker.person.fullName())
        .replace(/\{FIRSTNAME\}/g, faker.person.firstName())
        .replace(/\{LASTNAME\}/g, faker.person.lastName())

        // ✅ Base64 Encoding (Custom String & Links)
        .replace(/\{BASE64\((.*?)\)\}/g, (_, str) => encodeBase64(str))
        .replace(/\{LINK64\}/g, encodeBase64("https://yourdomain.com"))
        .replace(/\{URLENCODE\((.*?)\)\}/g, (_, str) => encodeUrl(str))
        .replace(/\{HTMLENTITY\((.*?)\)\}/g, (_, str) => encodeHtmlEntity(str))
        .replace(/\{HEX\((.*?)\)\}/g, (_, str) => encodeHex(str))

        // ✅ Extracted Data from CSV
        .replace(/\{FULLNAME\}/g, recipient.name)
        .replace(/\{INFODATA\}/g, recipient.info || "N/A") // Assumes 'info' column exists in CSV

        // ✅ Random Choice Between Options
        .replace(/\{PICK\((.*?)\)\}/g, (_, options) => {
            const choices = options.split("|");
            return choices[Math.floor(Math.random() * choices.length)];
        })

        // ✅ Email Username Transformations
        .replace(/\{CAPSUSERNAME\}/g, capitalizeFirstLetter(extractUsername(recipient.email)))
        .replace(/\{BLOCKUSERNAME\}/g, extractUsername(recipient.email).toUpperCase())
        .replace(/\{CAPSDOMAINNAME\}/g, capitalizeFirstLetter(extractDomainWithoutExtension(recipient.email)))
        .replace(/\{BLOCKDOMAINNAME\}/g, extractDomainWithoutExtension(recipient.email).toUpperCase())

        // ✅ Date & Time Formatting
        .replace(/\{TIMETYPE1\}/g, currentDate.toLocaleString("en-US", { dateStyle: "full", timeStyle: "medium" }))
        .replace(/\{TIMETYPE2\}/g, currentDate.toLocaleString("en-US"))
        .replace(/\{DATETYPE1\}/g, currentDate.toLocaleString("en-US", { month: "long", day: "numeric", year: "numeric" }))
        .replace(/\{DATETYPE2\}/g, currentDate.toLocaleDateString("en-US"))

        // ✅ Random String Generators
        .replace(/\{RANDOMSTRING25\}/g, getRandomString(25))
        .replace(/\{MD5RANDOM\}/g, crypto.createHash("md5").update(getRandomString(20)).digest("hex"))
        .replace(/\{SHA1RANDOM\}/g, crypto.createHash("sha1").update(getRandomString(20)).digest("hex"));
    }