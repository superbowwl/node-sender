import fs from "fs";
import winston from "winston";
import chalk from "chalk";

// ✅ Set log level (Options: "debug", "info", "warn", "error")
const LOG_LEVEL = process.env.LOG_LEVEL || "info";
const MINIMAL_LOGGING = process.env.MINIMAL_LOGGING?.toLowerCase() === "true" ?? true;
const FULL_LOGGING = process.env.FULL_LOGGING?.toLowerCase() === "true" ?? true;

// ✅ Helper to normalize messages (handles objects, errors, etc.)
const normalizeMessage = (msg) => {
    if (!msg) return "";
    if (typeof msg === "string") return msg;
    if (msg instanceof Error) return `${msg.message}\n${msg.stack}`;
    if (typeof msg === "object") return JSON.stringify(msg, null, 2); // Pretty-print objects
    return String(msg); // Fallback for other types
};

// ✅ Combined Filter and Console Format
const combinedFormat = winston.format.combine(
    winston.format((info) => {
        // Normalize the message before filtering
        info.message = normalizeMessage(info.message);
        if (!info.message || info.message.trim() === "") return false;

        // Full logging: log everything
        if (FULL_LOGGING) return info;

        // Minimal logging: filter based on important messages
        if (MINIMAL_LOGGING && !FULL_LOGGING) {
            const importantMessages = [
                "✅ Email sent successfully",
                "📨 Found ",
                "✅ Main thread running...",
                "✅ Email process completed",
                "🔗 Connecting to SMTP",
                "🚀 Preparing email for:"
            ];
            if (!importantMessages.some((msg) => info.message.includes(msg))) return false;
        }
        return info;
    })(),
    winston.format.errors({ stack: true }), // Handle stack traces
    winston.format.printf((info) => {
        let { level, message, stack } = info;

        // Append stack if present (beyond what normalizeMessage does)
        if (stack && !message.includes(stack)) {
            message += `\n🔍 Stacktrace:\n${stack}`;
        }

        // Colorize based on level
        switch (level) {
            case "error":
                return chalk.red(`[${new Date().toLocaleString()}] ${message}`);
            case "warn":
                return chalk.yellow(`[${new Date().toLocaleString()}] ${message}`);
            case "info":
                return chalk.green(`[${new Date().toLocaleString()}] ${message}`);
            case "debug":
                return chalk.blue(`[${new Date().toLocaleString()}] ${message}`);
            default:
                return `[${new Date().toLocaleString()}] ${message}`;
        }
    })
);

// 📝 File Formatter (Full Logs)
const fileFormat = winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ level, message, timestamp }) => {
        message = normalizeMessage(message); // Ensure consistent message handling
        return `[${timestamp}] [${level.toUpperCase()}] ${message}`;
    })
);

// ✅ Create Winston Logger
export const logger = winston.createLogger({
    level: LOG_LEVEL,
    transports: [
        new winston.transports.Console({
            format: combinedFormat,
        }),
        new winston.transports.File({
            filename: "./Services/mailer.log",
            format: fileFormat,
        }),
    ],
});

// ✅ Export Log Functions (Prevents Empty Logs)
export const log = {
    debug: (message) => {
        const msg = normalizeMessage(message);
        if (msg && msg.trim() !== "") logger.debug(msg);
    },
    info: (message) => {
        const msg = normalizeMessage(message);
        if (msg && msg.trim() !== "") logger.info(msg);
    },
    warn: (message) => {
        const msg = normalizeMessage(message);
        if (msg && msg.trim() !== "") logger.warn(msg);
    },
    error: (message) => {
        const msg = normalizeMessage(message);
        if (msg && msg.trim() !== "") logger.error(msg);
    },
};

export default log;