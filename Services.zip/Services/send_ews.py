#!/usr/bin/env python3
import warnings
warnings.filterwarnings(
    "ignore",
    message="Timezone offset does not match system offset",
    category=UserWarning,
    module="tzlocal.utils"
)

import mimetypes
import sys, json, time, base64
from exchangelib import (
    Credentials, Configuration, Account, DELEGATE,
    Message, Mailbox, FileAttachment, HTMLBody
)

def handle_job(job):
    # ————— connect —————
    creds = Credentials(job["user"], job["password"])
    cfg   = Configuration(server=job["endpoint"], credentials=creds)
    acc   = Account(job["user"], autodiscover=False, config=cfg,
                    access_type=DELEGATE)

    # ————— build the message —————
    msg = Message(
        account       = acc,
        subject       = job["subject"],
        body          = HTMLBody(job["html"]),
        to_recipients = [Mailbox(email_address=job["to"])],
        sender        = Mailbox(email_address=job["from"]),
        importance    = job["importance"],
        sensitivity   = job["sensitivity"],
    )

    # ————— attachments —————
    for att in job.get("attachments", []):
        if att.get("path"):
            data = open(att["path"], "rb").read()
        elif att.get("content"):
            data = base64.b64decode(att["content"])
        else:
            continue

        fa_kwargs = {"name": att["filename"], "content": data}
        if att.get("contentType"):
            fa_kwargs["content_type"] = att["contentType"]
        else:
            ctype, _ = mimetypes.guess_type(fa_kwargs["name"])
            if ctype:
                fa_kwargs["content_type"] = ctype

        if att.get("disposition") == "inline" and att.get("cid"):
            fa_kwargs["is_inline"]  = True
            fa_kwargs["content_id"] = att["cid"]

        msg.attach(FileAttachment(**fa_kwargs))

    # ————— send —————
    t0 = time.time()
    msg.send_and_save()
    return {"ok": True, "latency": int((time.time() - t0) * 1000)}

if __name__ == "__main__":
    while True:
        line = sys.stdin.readline()
        if not line:
            break
        line = line.strip()
        if not line:
            continue

        try:
            job = json.loads(line)
            res = handle_job(job)
        except Exception as e:
            res = {"ok": False, "err": str(e)}

        sys.stdout.write(json.dumps(res) + "\n")
        sys.stdout.flush()
