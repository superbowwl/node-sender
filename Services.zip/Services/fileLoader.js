import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import log from './logger.js';
import { config } from './loadConfig.js';


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


const EMAIL_SENDER_NAME = config.email?.sender_name;
const TEMPLATE_FILE = config.email?.template_file || 'Letter.html';
const SUBJECT_FILE_ENABLED = config.email?.subject_file_enabled ?? true;
const MULTIPLE_FILES_DIR = path.resolve(__dirname, '..');


let subjectsList = [];
let subjectIndex = 0;
let senderEmails = [];
let senderIndex = 0;

export async function loadEmailTemplate() {
  try {
    if (!(await fs.access(TEMPLATE_FILE).then(() => true).catch(() => false))) {
      log.warn(`⚠️ Email template file '${TEMPLATE_FILE}' not found! Using default template.`);
      return '<p>Hello,</p><p>This is a default email.</p>';
    }
    return (await fs.readFile(TEMPLATE_FILE, 'utf8')).trim();
  } catch (error) {
    log.error('❌ Error loading email template:', error.message);
    return '<p>Hello,</p><p>This is a default email.</p>';
  }
}

export async function loadSubjects() {
  try {
    if (config.email.subject && config.email.subject.trim() !== '') {
      return [config.email.subject];
    }
    if (SUBJECT_FILE_ENABLED && config.Multiple?.enableMultipleSubject) {
      const filePath = path.join(MULTIPLE_FILES_DIR, config.Multiple.subjectFile);
      if (await fs.access(filePath).then(() => true).catch(() => false)) {
        const subjects = (await fs.readFile(filePath, 'utf8'))
          .split('\n')
          .map(subject => subject.trim())
          .filter(subject => subject.length > 0);
        if (subjects.length > 0) {
        
          return subjects;
        }
      }
    }
    log.warn('⚠️ No valid subjects found. Emails will be sent without a subject.');
    return [''];
  } catch (error) {
    log.error('❌ Error loading subjects list:', error.message);
    return [''];
  }
}

export async function loadFromEmails() {
  try {
    if (!config.Multiple || !config.Multiple.enableMultipleFromMail) {
      return [config.email.from_email || 'default@example.com'];
    }
    const filePath = path.join(MULTIPLE_FILES_DIR, config.Multiple.fromMailList);
    if (!(await fs.access(filePath).then(() => true).catch(() => false))) {
      log.warn(`⚠️ FromMail file '${filePath}' not found! Using default sender email.`);
      return [config.email.from_email || 'default@example.com'];
    }
    const emails = (await fs.readFile(filePath, 'utf8'))
      .split('\n')
      .map(email => email.trim())
      .filter(email => email.length > 0);
    if (emails.length === 0) {
      log.warn(`⚠️ No valid emails found in '${filePath}'. Using default sender email.`);
      return [config.email.from_email || 'default@example.com'];
    }
    return emails;
  } catch (error) {
    log.error('❌ Error loading FromMail list:', error.message);
    return [config.email.from_email || 'default@example.com'];
  }
}

export async function getNextSubject() {
  if (!subjectsList.length) subjectsList = await loadSubjects();
  const subject = subjectsList[subjectIndex] || '';
  subjectIndex = (subjectIndex + 1) % subjectsList.length;
  return subject;
}

export async function getNextSenderEmail() {
  if (!senderEmails.length) senderEmails = await loadFromEmails();
  const email = senderEmails[senderIndex] || config.email.from_email || 'default@example.com';
  senderIndex = (senderIndex + 1) % senderEmails.length;
  return email;
}

export { EMAIL_SENDER_NAME, TEMPLATE_FILE, subjectsList, subjectIndex, senderEmails, senderIndex };