import yaml from "js-yaml";
import fs from "fs";
import log from "./logger.js";



const loadConfig = () => {
  try {
    const loadedConfig = yaml.load(fs.readFileSync("config.yml", "utf8")) || {};
// after you load YAML into `loadedConfig`
if (Array.isArray(loadedConfig.attachments?.inline_images?.list)) {
  loadedConfig.attachments.inline_images.list =
    loadedConfig.attachments.inline_images.list.map(img => ({
      ...img,
      location: img.location.trim(),   // ← strips \r \n and spaces
      cid: (img.cid || "").trim()
    }));
}

    // ✅ Ensure critical objects exist to prevent 'undefined' errors
    loadedConfig.ai = loadedConfig.ai || {}; 
    loadedConfig.proxy = loadedConfig.proxy || {};
    loadedConfig.proxy.enable = loadedConfig.proxy.enable || 0;
    loadedConfig.proxy.list = loadedConfig.proxy.list || [];
    loadedConfig.attachments = loadedConfig.attachments || {};
    loadedConfig.attachments.inline_image = loadedConfig.attachments
      .inline_image || { enable: 0 };
    loadedConfig.attachments.text_files = loadedConfig.attachments
      .text_files || { enable: 0, files: [] };

    loadedConfig.pdf = loadedConfig.pdf || {
      enable: 0,
      location: "",
      filename: "",
    };
    loadedConfig.docx = loadedConfig.docx || {
      enable: 0,
      location: "",
      filename: "",
    };
    loadedConfig.eml = loadedConfig.eml || {
      enable: 0,
      location: "",
      filename: "",
    };

    // ✅ Ensure critical objects exist to prevent 'undefined' errors
    loadedConfig.pqueue = loadedConfig.pqueue || { enabled: 0, concurrency: 1 };
    loadedConfig.bullmq = loadedConfig.bullmq || { enabled: 0, concurrency: 1 };

    loadedConfig.Sender_Config = loadedConfig.Sender_Config || {};
    loadedConfig.Smtp_Config = loadedConfig.Smtp_Config || {};

    // ✅ Ensure safe defaults for sender and SMTP
    loadedConfig.Sender_Config.pool = loadedConfig.Sender_Config.pool || 0;
    loadedConfig.Smtp_Config.limit_per_second =
      loadedConfig.Smtp_Config.limit_per_second || 1;

    // ✅ Ensure default values for links configuration
    loadedConfig.links = loadedConfig.links || {};
    loadedConfig.links.enable = loadedConfig.links.enable ?? true;
    loadedConfig.links.use_file = loadedConfig.links.use_file ?? false;
    loadedConfig.links.file_path = loadedConfig.links.file_path || "links.txt";
    loadedConfig.links.predefined_links =
      loadedConfig.links.predefined_links || [];
    loadedConfig.links.fallback_link =
      loadedConfig.links.fallback_link || "https://defaultlink.com";

    //  log.info("✅ Config Loaded Successfully:", JSON.stringify(loadedConfig, null, 2));
    return loadedConfig;
  } catch (error) {
    log.error("❌ Error loading config.yml:", error);
    return {};
  }
};


export function getHtmlFilePath(config) {
  if (config.pdf?.enable) {
    return config.pdf.location;
  } else if (config.Htmlimage?.enable) {
    return config.Htmlimage.location;
  } else if (config.docx?.enable) {
    return config.docx.location;
  } else if (config.rtf?.enable) {
    return config.rtf.location;
  } else if (config.odt?.enable) {
    return config.odt.location;
  } else if (config.eml?.enable) {
    return config.eml.location;
  } else if (config.text_files?.enable && config.text_files.files.length > 0) {
    return config.text_files.files[0].path;
  }
  return null; // No valid file path found
}
export const config = loadConfig();
