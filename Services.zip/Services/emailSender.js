import PQueue from 'p-queue';
import log from './logger.js';
import chalk from 'chalk';
import { config, getHtmlFilePath } from './loadConfig.js';
import { initializeTransporter, getNextSmtpConfig,loadSmtpConfigs, smtpSelectLock } from './smtp.js';
import { readRecipients, filterDuplicates } from './recipientLoader.js';
import { loadEmailTemplate, getNextSubject, getNextSenderEmail, EMAIL_SENDER_NAME } from './fileLoader.js';
import { initializeVpn, processVpn } from './vpnManager.js';
import { getNextProxy } from './proxyManager.js';
import { replacePlaceholders } from './placeholders.js';
import { addAttachments } from './attachments.js';
import aiContentGenerator from './aiGenerator.js';
import nodemailer from 'nodemailer';
//import { loadEwsAccounts,getNextEws, sendViaEws } from './ews.js';

let transporter = null;




function closeTransporter() {
    if (transporter?.options?.pool && transporter?.isIdle) {
        log.info('🚪 Closing idle pooled transporter.');
        transporter.close();
    } else if (transporter) {
         log.debug('Transporter is non-pooled or busy, releasing reference.');
    }
    transporter = null; // Always release the reference
}

// Assign proxy if enabled
// async function assignProxyIfEnabled(currentTransporter, smtpConfig) { // Pass transporter
//     if (!currentTransporter) {
//         log.warn('⚠️ Cannot assign proxy, transporter is invalid.');
//         return;
//     }
//     if (config.proxy?.enable) {
//         const proxyAgent = await getNextProxy();
//         if (proxyAgent?.proxyUri) {
//             log.info(`🔌 Using Proxy: ${proxyAgent.proxyUri} for ${smtpConfig.auth.user}`);
//             // Assign proxy to the options of the current transporter instance
//             currentTransporter.options.proxy = proxyAgent.proxyUri;
//         } else {
//             log.warn(`⚠️ No working proxy found for ${smtpConfig.auth.user}. Proceeding without proxy.`);
//             // Ensure proxy is not set if none found
//             delete currentTransporter.options.proxy;
//         }
//     } else {
//          // Ensure proxy is not set if disabled
//          if(currentTransporter.options) delete currentTransporter.options.proxy;
//     }
// }

// Prepare email content with dynamic placeholders
async function prepareEmailContent(recipient, smtpConfig) {
    let emailSubject = config.ai?.enable ? await aiContentGenerator.getNextSubject() : await getNextSubject();
    let emailTemplate = recipient.emailTemplate || (config.ai?.enable ? await aiContentGenerator.getNextTemplate() : await loadEmailTemplate());

    emailSubject = await replacePlaceholders(emailSubject, recipient, smtpConfig);
    if (!recipient.emailTemplate) {
        emailTemplate = await replacePlaceholders(
          emailTemplate,
          recipient,
          smtpConfig
         );
       }

  const dynamicSenderName = await replacePlaceholders(EMAIL_SENDER_NAME, recipient, smtpConfig);
  const dynamicFromEmail = await replacePlaceholders(await getNextSenderEmail(), recipient, smtpConfig);

  if (!dynamicFromEmail) throw new Error('Missing sender email');

  const fromDomain = dynamicFromEmail.split('@')[1] || 'yourdomain.com';
  emailTemplate = emailTemplate.replace(/\{FROMDOMAIN\}/g, fromDomain);

  const fromHeader = `"${dynamicSenderName}" <${dynamicFromEmail}>`;

  return { emailSubject, emailTemplate, fromHeader };
}

// Send individual email with retry logic
export async function sendEmail(recipient,smtpConfig) {
    const startTime = Date.now();
    const retryDelayBase = config.Sender_Config.retryDelayBase ?? 1000;
    

  try {
    const selectedSmtpConfig = smtpConfig; // Reset selectedSmtpConfig for each email attempt
    const transporter = nodemailer.createTransport({
      timeout: 30000,
      host: smtpConfig.host,
      port: smtpConfig.port,
      secure: smtpConfig.secure,
      auth: smtpConfig.auth,
      pool: config.Sender_Config.pool === 1 || config.Sender_Config.pool === true,
      maxConnections: (config.Sender_Config.pool ? config.Sender_Config.max_connections : undefined),
      maxMessages:    (config.Sender_Config.pool ? config.Sender_Config.max_messages : undefined),
      rateLimit: config.Sender_Config.rate_limit === 1 || config.Sender_Config.rate_limit === true,
    });
  
    await transporter.verify();

  

    const { emailSubject, emailTemplate, fromHeader } = await prepareEmailContent(recipient, smtpConfig);

    const sensitivityMap = { 0: 'Normal', 1: 'Personal', 2: 'Private', 3: 'Company-Confidential' };
    const priorityMap = { 1: 'Highest', 2: 'High', 3: 'Normal', 4: 'Low', 5: 'Lowest' };

    const mailOptions = {
      from: fromHeader,
      to: recipient.email,
      subject: emailSubject,
      html: emailTemplate,
      headers: {
        Sensitivity: sensitivityMap[config.email.emailSensitivity] || 'Normal',
        Importance: (priorityMap[config.email.emailPriority] || 'Normal').toLowerCase(),
      },
      attachments: recipient.attachments,
    };

    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const info = await transporter.sendMail(mailOptions);
        const latency = Date.now() - startTime;

        const accepted = (info.accepted || []).map(e => e.toLowerCase());
                if (accepted.includes(recipient.email.toLowerCase())) {
                    log.info(`[${recipient.lineNumber}] ✅ Email sent to ${chalk.blue(recipient.email)} via ${chalk.yellow(selectedSmtpConfig.auth.user)}: ${chalk.magenta(fromHeader)}`);

                  //  incrementCounter(selectedSmtpConfig);

                } else {
                    log.warn(`[${recipient.lineNumber}] ⚠ Email to ${recipient.email} via ${selectedSmtpConfig.auth.user} not accepted by server: ${info.response || 'No response'}`);
                    // Do NOT increment count if not accepted
                }

                return; // exit on success
  } catch (err) {
    const code = err.responseCode;
    const resp = err.response || '';

    log.error(`❌ Attempt ${attempt} failed for ${recipient.email} via ${selectedSmtpConfig.auth.user}: ${err.message}`);

    // 1) Handle known transient network/timeouts
    if (['ECONNRESET','ETIMEDOUT'].includes(err.code) || err.message.includes('Timeout')) {
      log.warn(`Transient connection issue, retrying…`);
      closeTransporter(); // force a fresh connection next time

    // 2) Handle auth/envelope errors that shouldn’t be retried
    } else if (err.code === 'EENVELOPE' && code >= 500) {
      log.error(`❌ SMTP Error ${code} – permanent envelope failure. Not retrying.`);
      break;

    } else if (err.code === 'EAUTH' || err.message.includes('Missing credentials')) {
      log.error(`❌ Authentication failure. Not retrying.`);
      break;

    // 3) **Any other 5xx** → permanent
    } else if (code >= 500 || /^5\d\d/.test(resp)) {
      log.error(`❌ Permanent SMTP error ${code || resp.split(' ')[0]}. Not retrying.`);
      break;

    // 4) Otherwise it's probably a 4xx (transient) – let it retry
    } else {
      const delay = retryDelayBase * Math.pow(2, attempt - 1);
      log.warn(`❗ Transient SMTP response (${code || resp}). Waiting ${delay}ms before retry…`);
      await new Promise(r => setTimeout(r, delay));
    }
  }
}
    } catch (err) {
        // Catch errors from transporter init or final retry failure
        log.error(`[${recipient.lineNumber}] ❌ Failed to send email to ${recipient.email} via ${smtpConfig?.auth?.user || 'unknown SMTP'}: ${err.message}`);
       
    }
}


export function incrementCounter(smtpConfig) {
    smtpConfig.counter += 1;
    console.log(`Incremented counter for ${smtpConfig.auth.user} to ${smtpConfig.counter}`);
}

// Process email attachments in batches
async function processAttachments(recipients, emailTemplate,smtpConfig) {
  const hasAttachments = config.pdf?.enable || config.docx?.enable || config.odt?.enable ||
    config.rtf?.enable || config.eml?.enable || config.Htmlimage?.enable || config.qr_code?.enable ||
    (config.attachments?.inline_images?.enable && config.attachments.inline_images.list?.length) ||
    (config.attachments?.text_files?.enable && config.attachments.text_files.files?.length);

  if (!hasAttachments) return recipients;

//let smtpConfig = null;
  try {
    //  smtpConfig = await getNextSmtpConfig();
  } catch (e) {
      log.warn(`⚠️ Could not get initial SMTP config for attachment placeholder context: ${e.message}. Placeholders depending on SMTP might fail.`);
      // Proceed without it, placeholders might resolve to defaults or error later
  }


  const batchSize = 10;
  const batched = [];
  for (let i = 0; i < recipients.length; i += batchSize) {
    batched.push(recipients.slice(i, i + batchSize));
  }

  const enrichedRecipients = [];
  for (const batch of batched) {
    const results = await addAttachments(config, batch, smtpConfig|| {}, [], emailTemplate);
    batch.forEach((recipient, i) => {
      enrichedRecipients.push({
        ...recipient,
        attachments: results[i].attachments,
        emailTemplate: results[i].emailTemplate,
      });
    });
  }
  return enrichedRecipients;
}

// Send bulk emails
export async function sendBulkEmails() {
  let recipients = await readRecipients();
  if (!recipients.length) throw new Error('⚠ No valid recipients found');

  log.info(`📨 Found ${recipients.length} valid recipients`);

  const channel = (config.Mail_Channel || '').toLowerCase();
  if (channel !== 'smtp' && channel !== 'ews')
      throw new Error('Mail_Channel must be smtp or ews');
  let ews;
  try {
       if (channel === 'smtp') {
      await loadSmtpConfigs();
    }

    // only load EWS if we need it:
    
    if (channel === 'ews') {
      ews = await import('./ews.js');
      await ews.loadEwsAccounts();
    }

      log.info('✅ Account configurations loaded.');
  } catch (err) {
      log.error(`❌ Failed to load account list: ${err.message}`);
      return;
  }

  if (config.vpn?.enable) await initializeVpn();

  recipients = await filterDuplicates(recipients, config);

  
  const emailTemplate = await loadEmailTemplate();
  recipients = await processAttachments(recipients, emailTemplate);

  await processEmails(recipients,ews);
}


// 📌 Process Emails with VPN Rotation and Optional PQueue
// ========================================================
export async function processEmails(recipients,ews) {
  const channel = (config.Mail_Channel || '').toLowerCase();
  if (channel !== 'smtp' && channel !== 'ews') {
    throw new Error('config.Mail_Channel must be "smtp" or "ews"');
  }
  

    const useQueue = config.pqueue?.enabled;
    const queue = useQueue
        ? new PQueue({
            concurrency: config.pqueue.concurrency || 1,
            intervalCap: config.pqueue.intervalCap || 1,
            interval: config.pqueue.interval || 500,
        })
        : null;

        const ewsQueue = config.Ews_Config.enable
  ? new PQueue({ concurrency: config.Ews_Config.concurrency })
  : null;

    const maxEmailsBeforeDelay = config.Sender_Config.maxEmailsBeforeDelay ?? 0; // 0 means no delay
    const delayAfterMaxEmails = (config.Sender_Config.delayAfterMaxEmails ?? 0) * 1000; // 0 means no delay
    const maxEmailsPerVpn = config.vpn?.enable ? (config.vpn.max_emails_per_vpn || 0) : 0; // 0 means no VPN rotation based on count

    // Determine batch size based on VPN or Delay needs. If neither is set, process individually (or let PQueue handle concurrency)
    // This batch size is mainly for VPN rotation and delay logic, not strict sending batches.
    const vpnBatchTrigger = (maxEmailsPerVpn > 0) ? maxEmailsPerVpn : Infinity;
    const delayBatchTrigger = (maxEmailsBeforeDelay > 0 && delayAfterMaxEmails > 0) ? maxEmailsBeforeDelay : Infinity;
    // The effective trigger point is the smaller of the two counts requiring action (VPN rotation or delay)
    const actionTriggerPoint = Math.min(vpnBatchTrigger, delayBatchTrigger);


    let emailsSentSinceLastVpn = 0;
    let emailsSentSinceLastDelay = 0;
    let totalSentSuccessfully = 0;
    let totalFailed = 0;
    let smtpExhausted = false;          // global flag for this run

    function isExhaustedError(err) {
      return /All SMTP accounts have reached/i.test(err.message);
    }
    

    const processRecipient = async (recipient, index) => {
         // --- FIX #2: Fetch SMTP Config JUST BEFORE sending attempt ---


/* -------- personalised content (unchanged) -------- */
const { emailSubject, emailTemplate,fromHeader } =
      await prepareEmailContent(recipient, {});
const senderEmail =
      fromHeader.match(/<([^>]+)>/)?.[1];

      const formattedAttachments = (recipient.attachments ?? []).map(att => {
        const out = {
          filename: att.filename
        };
        if (att.path) {
          out.path = att.path;
        } else if (att.content) {
          // if it’s a Buffer, convert to base64 string
          const buf = Buffer.isBuffer(att.content)
          ? att.content
          : Buffer.from(att.content);
        out.content = buf.toString('base64');
      }
      
        // carry over these if present:
        if (att.contentType)  out.contentType  = att.contentType;
        if (att.disposition)  out.disposition  = att.disposition;
        if (att.cid)          out.cid          = att.cid;
        return out;
      });
      

const mailJob = {
  to:   recipient.email,
  from: senderEmail,
  subject: emailSubject,
  html: recipient.emailTemplate || emailTemplate,
  importance: {1:'High',2:'High',3:'Normal',4:'Low',5:'Low'}[config.email.emailPriority]||'Normal',
  sensitivity:{0:'Normal',1:'Personal',2:'Private',3:'Confidential'}[config.email.emailSensitivity]||'Normal',
         // array of {path|content, cid, filename, [contentType]}
  attachments: formattedAttachments,  
};
//console.log("DEBUG mailJob.attachments:", formattedAttachments[0]);


/* ===================================================
   CHANNEL: EWS
   ===================================================*/
   if (channel === 'ews') {
    
      if (!ewsQueue) {
   log.error('🚫 EWS queue is not enabled in config.Ews_Config.enable; cannot send via EWS.');
   totalFailed++;
   return;
 }
  ewsQueue.add(async () => {
        const acc = await ews.getNextEws();
        const { latency } = await ews.sendViaEws(mailJob, acc);
        log.info(`✅ Sent ${recipient.email} via EWS ${acc.user} in ${latency}ms`);
        totalSentSuccessfully++;
      })
      .catch(err => {
        log.error(`❌ EWS send failed for ${recipient.email}: ${err.message}`);
        totalFailed++;
      });
  
      return;
    }

/* ===================================================
   CHANNEL: SMTP
   ===================================================*/
   if (channel === 'smtp') {

    if (smtpExhausted) return;          // queue already drained

    /* pick an SMTP account */
    let currentSmtpConfig = null;
    try {
        currentSmtpConfig = await getNextSmtpConfig();   // may throw

        // log.info(
        //   `[${recipient.lineNumber || index + 1}] Selected SMTP: ` +
        //   `${currentSmtpConfig.auth.user} (Counter: ${currentSmtpConfig.counter})`
        // );

    } catch (error) {
        if (isExhaustedError(error)) {
            smtpExhausted = true;
            log.warn('🚫 All SMTP quotas exhausted. Pausing the queue and ending the run.');

            if (useQueue) {
                queue.pause();          // stop accepting new tasks
                queue.clear();          // drop tasks not yet started
            }
            return;                     // skip this recipient
        }

        // any other selection error
        log.error(
          `[${recipient.lineNumber || index + 1}] ❌ Error getting SMTP for ` +
          `${recipient.email}: ${error.message}. Skipping.`
        );
        totalFailed++;
        return;
    }

    /* send the message */
    try {
        await sendEmail(recipient, currentSmtpConfig);
        totalSentSuccessfully++;
        emailsSentSinceLastVpn++;
        emailsSentSinceLastDelay++;

    } catch (err) {
        log.error(
          `[${recipient.lineNumber || index + 1}] ❌ Final failure for ` +
          `${recipient.email}: ${err.message}`
        );
        totalFailed++;
    }

         // --- Post-send actions (VPN rotation, Delay) ---
         return;     // SMTP branch finished
}};

    // --- Main Execution Logic ---
    if (useQueue) {
        // Add all tasks to the queue
        log.info(
               `🚦 Processing ${recipients.length} emails with concurrency ${config.pqueue.concurrency}...`
             );
        
            for (let i = 0; i < recipients.length; i++) {
                 if (smtpExhausted) break;            // stop feeding if quotas full
        
                queue.add(() =>
                    processRecipient(recipients[i], i).catch(err => {
                         log.error(`💥 Unhandled error in queued task: ${err.message}`);
                         console.error(err.stack);  
                        totalFailed++;
                     })
                );
           }
        
            await queue.onIdle();                    // resolves when queue empty
            // Wait for queue to finish
    } else {
        // Process sequentially
        log.info(`🚦 Processing ${recipients.length} emails sequentially...`);
        for (let i = 0; i < recipients.length; i++) {
          if (smtpExhausted) break; 
            await processRecipient(recipients[i], i);
        }
    }
    if (channel === 'ews' && config.Ews_Config.enable) {
      // Wait for all enqueued EWS jobs to finish
      await ewsQueue.onIdle();
    }
    log.info('------------------------------------');
    log.info(`📊 Processing Summary:`);
    log.info(`   Total Recipients Attempted: ${recipients.length}`);
    log.info(`   ✅ Successfully Sent: ${totalSentSuccessfully}`);
    log.info(`   ❌ Failed: ${totalFailed}`);
    log.info('------------------------------------');

    closeTransporter(); // Final cleanup
}
