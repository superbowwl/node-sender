import fs from "fs";
import path from "path";
import { replacePlaceholders,getLogoUrl } from "./placeholders.js";
import {
    convertToDocx,
    convertToPdf,
    convertToEml,
    convertToRtf,
    convertToOdt,
    convertToImage
} from "./conversions.js";
import chardet from "chardet";
import iconv from "iconv-lite";
import { log } from "./logger.js";
import { fileURLToPath } from "url";
import QRCode from 'qrcode';
import fetch from 'node-fetch';
import { type } from "os";



const __dirname = path.dirname(import.meta.url ? fileURLToPath(import.meta.url) : __filename);



async function attachLogoIfNeeded(recipient, html) {
  if (!html.includes("cid:companylogo@cid")) return;
  if (recipient.attachments?.some(a => a.cid === "companylogo@cid")) return;

  const primaryUrl = getLogoUrl(recipient.email);
  const fallbackUrl = "https://na1.documents.adobe.com/images/emailNextGen/email-adobe-sign-logo.3@2x.png";

  let buffer;
  try {
    // try primary Clearbit logo
    const res = await fetch(primaryUrl);
    if (!res.ok || res.headers.get("content-length") === "0") {
      throw new Error(`Primary logo fetch failed: ${res.status}`);
    }
    buffer = await res.arrayBuffer();
  } catch (err) {
    // fallback to Adobe Sign logo
    const res = await fetch(fallbackUrl);
    if (!res.ok) {
      log.error(`❌ Both logo fetches failed: clearbit=${primaryUrl}, fallback=${fallbackUrl}, err=${err}`);
      return; // give up entirely
    }
    buffer = await res.arrayBuffer();
  }

  return {
    filename: `${recipient.email.split("@")[1].split(".")[0]}.png`,
    content: Buffer.from(buffer),
    cid: "companylogo@cid",
    contentType: "image/png",
    contentDisposition: "inline",
  };
}

// Generates QR code attachment if enabled and referenced in template
export async function generateQrCodeAttachment(recipient, config, smtpConfig) {
  if (!config.qr_code?.enable) {
      //log.info("QR code generation disabled in config");
      return null;
  }

  const qrCodeCid = `qrcode_${recipient.email.replace(/[@.]/g, "_")}_default`;
  // Check for {QR_CODE} or its cid reference
  if (!recipient.processedTemplate.includes(`{QR_CODE}`) && !recipient.processedTemplate.includes(`cid:${qrCodeCid}`)) {
      log.info(`No QR code placeholder found for ${recipient.email}`);
      return null;
  }

  
      // Replace {QR_CODE} with cid reference if not already done
      if (recipient.processedTemplate.includes("{QR_CODE}")) {
          recipient.processedTemplate = recipient.processedTemplate.replace(
              "{QR_CODE}",
              `<img src="cid:${qrCodeCid}" alt="QR Code" />`
          );
         // log.info(`Replaced {QR_CODE} with cid:${qrCodeCid} for ${recipient.email}`);
      }

      const qrCodeData = await replacePlaceholders(config.qr_code.data, recipient, smtpConfig);
      const qrCodeBuffer = await QRCode.toBuffer(qrCodeData, config.qr_code.options || {});
      return {
          filename: await replacePlaceholders(config.qr_code.filename || "qrcode.png", recipient, smtpConfig),
          content: qrCodeBuffer,
          contentType: "image/png",
          cid: qrCodeCid,
          disposition: "inline"
      };
  } 

  export async function generateInlineImageAttachments(recipient, config, smtpConfig) {
    if (!config.attachments?.inline_images?.enable) {
       // log.info("Inline images disabled in config");
        return [];
    }
    if (!recipient.processedTemplate.includes("{INLINE_IMAGE_")) {
        return [];
    }

    const attachments = [];
    const inlineImages = config.attachments.inline_images.list || [];
    const placeholderRegex = /\{INLINE_IMAGE_([^}]+)\}/g;
    let match;

    while ((match = placeholderRegex.exec(recipient.processedTemplate)) !== null) {
        const cid = match[1];
        const image = inlineImages.find(img => img.cid === cid);
        if (!image) {
            throw new Error(`No image with cid:${cid} found in config for {INLINE_IMAGE_${cid}}`);
        }

        const imagePath = path.join(image.location);
        if (!fs.existsSync(imagePath)) {
            throw new Error(`Image file not found for cid:${cid}: ${imagePath}`);
        }

        recipient.processedTemplate = recipient.processedTemplate.replace(
            `{INLINE_IMAGE_${cid}}`,
            `cid:${cid}`
        );
       // log.info(`Replaced {INLINE_IMAGE_${cid}} with cid:${cid} for ${recipient.email}`);
        attachments.push({
            filename: await replacePlaceholders(image.filename || "inline_image.png", recipient, smtpConfig),
            path: imagePath,
            cid: cid,
            disposition: "inline"
        });
    }

    return attachments;
}


async function generateTextAttachments(recipient, config, smtpConfig) {
    if (!config.attachments?.text_files?.enable) return [];

    const attachments = [];
    for (const file of config.attachments.text_files.files || []) {
        const filePath = file.path;
        if (!fs.existsSync(filePath)) {
            throw new Error(`Text file not found: ${filePath}`);
        }

        const detectedEncoding = chardet.detect(fs.readFileSync(filePath)) || "utf-8";
        const content = iconv.decode(fs.readFileSync(filePath), detectedEncoding);
        const processedContent = await replacePlaceholders(content, recipient, smtpConfig);
        attachments.push({
            type: "text_files",
            filename: await replacePlaceholders(file.filename, recipient, smtpConfig),
            content: processedContent,
            contentType: filePath.endsWith(".html") ? "text/html" : "text/plain"
        });
    }
    return attachments;
}

async function generateImageAttachment(recipient, config, smtpConfig) {
    if (!config.Htmlimage?.enable || !recipient.processedTemplate.includes("{html2img}")) return null;

    const imageResult = await convertToImage(config.Htmlimage.location, recipient, smtpConfig, config);
    if (!imageResult) {
        recipient.processedTemplate = recipient.processedTemplate.replace("{html2img}", "");
        return null;
    }

    const imageCid = `htmlimage_${recipient.email.replace(/[@.]/g, "_")}`;
    const clickableLink = config.Htmlimage.ClickableImageLink
        ? `<a href="${await replacePlaceholders(config.Htmlimage.ClickableImageLink, recipient, smtpConfig)}"><img src="cid:${imageCid}" alt="${imageResult.filename}" /></a>`
        : `<img src="cid:${imageCid}" alt="${imageResult.filename}" />`;
    recipient.processedTemplate = recipient.processedTemplate.replace("{html2img}", clickableLink);

    return {
        filename: imageResult.filename,
        content: imageResult.buffer,
        contentType: "image/png",
        cid: imageCid,
        disposition: "inline"
    };
}

// Generates attachments for various document formats
async function generateConvertedAttachments(recipient, config, smtpConfig, nestedAttachments) {
    const attachments = [];
    const conversions = [
        { type: "docx", fn: convertToDocx, contentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
        { type: "pdf", fn: convertToPdf, contentType: "application/pdf" },
        { type: "odt", fn: convertToOdt, contentType: "application/vnd.oasis.opendocument.text" },
        { type: "rtf", fn: convertToRtf, contentType: "application/rtf" },
       // { type: "eml", fn: convertToEml, contentType: "message/rfc822" }
    ];

     for (let {type, fn, contentType} of conversions) {
    if (!config[type]?.enable) continue
    const result = await fn(
      config[type].location,
      recipient,
      smtpConfig,
      config,
      // only pass nestedAttachments into EML call:
     // type === "eml" ? nestedAttachments : undefined
     nestedAttachments
    )
    if (!result) continue// ======== replace from here ========
let buffer;

// 1) if converter returned an object with a .buffer property, normalize it
if (result.buffer != null) {
  // Buffer.from handles Buffers, ArrayBuffers, TypedArrays, etc.
  buffer = Buffer.from(result.buffer);
}
// 2) converter returned a Buffer directly
else if (Buffer.isBuffer(result)) {
  buffer = result;
// 3) converter returned a string of raw bytes
} else if (typeof result === "string") {
  buffer = Buffer.from(result, "latin1");
} else {
  throw new Error(`Converter for type=${type} didn’t return a Buffer or binary string`);
}
// ======== replace up to here ========



// … rest of your nesting logic follows …

    const filename = await replacePlaceholders(config[type].filename, recipient, smtpConfig)

    // if this type is marked to be *nested* inside the final EML, stash it:
    const shouldNest =
     // type !== "eml" &&
      config.eml?.nest?.enable &&
      config.eml.nest.types.includes(type)

    if (shouldNest) {
      nestedAttachments.push({ filename, contentType, content: buffer })
    } else {
      // otherwise it’s a standalone attachment
      const att = {
        filename,
        content: buffer,
        contentType
      }
      // your existing .eml‐attachment flags (only for the EML itself):
      if (type === "eml") {
        Object.assign(att, {
          contentDisposition: "attachment",
          encoding:           "base64",
          contentTransferEncoding: "7bit"
        })
      }
      attachments.push(att)
    }
  }

  return attachments
}


function handleAttachment(att, nestedAttachments, rAttachments, config) {
  // att must have: { type, filename, contentType, content, [cid, disposition, path...] }
  const { type, filename, contentType, content } = att;
  const shouldNest =
       config.eml?.nest?.enable &&
       config.eml.nest.types.includes(type) &&
       type !== "eml";  // never nest the EML itself

  if (shouldNest) {
    nestedAttachments.push({ filename, contentType, content: Buffer.isBuffer(content) ? content : Buffer.from(content, "utf8") });
  } else {
    rAttachments.push(att);
  }
}



// Main function to add attachments for recipients
export async function addAttachments(config, recipient, smtpConfig, attachments = [], emailTemplate) {
    
       
        if (!Array.isArray(attachments)) {
            log.error(`❌ Attachments for ${recipient.email} is not an array: ${JSON.stringify(attachments)}`);
            attachments = [];
          }
      
        const recipients = Array.isArray(recipient) ? recipient : [recipient];

        // Process all recipients
        return await Promise.all(recipients.map(async r => {
            let processedTemplate = await replacePlaceholders(emailTemplate, r, smtpConfig );
            const recipientData = { ...r, processedTemplate };
            const rAttachments = [];
            const nestedAttachments = []; 
try { const logo = await attachLogoIfNeeded(recipientData, processedTemplate);
            if (logo) rAttachments.push(logo);
      
            // Generate all attachment types if enabled in config
            const qrCode = await generateQrCodeAttachment(recipientData, config, smtpConfig);
            if (qrCode) rAttachments.push(qrCode);

            const inlineImages = await generateInlineImageAttachments(recipientData, config, smtpConfig);
            if (inlineImages.length) rAttachments.push(...inlineImages);

            const textFiles = await generateTextAttachments(recipientData, config, smtpConfig);
            for (const att of textFiles) {
  handleAttachment(att, nestedAttachments, rAttachments, config);
}

            const image = await generateImageAttachment(recipientData, config, smtpConfig);
            if (image) rAttachments.push(image);
           
            const converted = await generateConvertedAttachments(recipientData, config, smtpConfig,nestedAttachments);
            if (converted.length) rAttachments.push(...converted);

            if (config.eml.enable) {
  const emlStr = await convertToEml(
    config.eml.location,
    recipientData,
    smtpConfig,
    config,
    nestedAttachments    // ← everything you wanted nested
  );
  rAttachments.push({
    filename:                 await replacePlaceholders(config.eml.filename, recipientData, smtpConfig),
    content:                  Buffer.from(emlStr, "utf8"),
    contentType:              "message/rfc822",
    contentDisposition:       "attachment",
    encoding:                 "base64",
    contentTransferEncoding:  "7bit"
  });
}


           
            return {
                attachments: rAttachments,
                emailTemplate: recipientData.processedTemplate
            };
        } catch (error) {
            log.error(`❌ Failed to process attachments for ${recipientData.email}: ${error.message}`, { stack: error.stack });
            throw error;
        }
    }));
}
