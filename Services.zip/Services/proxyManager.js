import fs from 'fs/promises';
import { SocksClient } from 'socks';
import { SocksProxyAgent } from 'socks-proxy-agent';
import net from 'net';
import log from './logger.js';
import { config } from './loadConfig.js';
import { sharedData, sharedState } from './sharedState.js';



export async function readProxiesFromFile(filePath) {
  try {
    if (!(await fs.access(filePath).then(() => true).catch(() => false))) {
      log.warn(`⚠️ Proxy file not found: ${filePath}`);
      return [];
    }
    const fileContent = await fs.readFile(filePath, 'utf8');
    const lines = fileContent.split('\n').map(line => line.trim()).filter(line => line);
    const proxies = [];
    for (const line of lines) {
      try {
        const parsedUrl = new URL(line);
        const proxy = { url: `socks5://${parsedUrl.hostname}:${parsedUrl.port}` };
        if (parsedUrl.username) proxy.username = parsedUrl.username;
        if (parsedUrl.password) proxy.password = parsedUrl.password;
        proxies.push(proxy);
      } catch (urlError) {
        const parts = line.split(':');
        if (parts.length === 2 || parts.length === 4) {
          const [host, port, username, password] = parts;
          const proxy = { url: `socks5://${host}:${port}` };
          if (username) proxy.username = username;
          if (password) proxy.password = password;
          proxies.push(proxy);
        } else {
          log.warn(`⚠️ Invalid proxy format in file: ${line}`);
        }
      }
    }
    log.info(`✅ Loaded ${proxies.length} proxies from ${filePath}`);
    return proxies;
  } catch (error) {
    log.error(`❌ Error reading proxy file ${filePath}: ${error.message}`);
    return [];
  }
}

export async function testProxy(proxyUrl) {
    try {
      const parsed = new URL(proxyUrl);
      const options = {
        proxy: {
          ipaddress: parsed.hostname,
          port: parseInt(parsed.port, 10),
          type: 5,
          userId: parsed.username || undefined,
          password: parsed.password || undefined,
        },
        command: 'connect',
        destination: {
          host: '1.1.1.1',
          port: 53,
        },
        timeout: 5000,
      };
  
      const info = await SocksClient.createConnection(options);
      info.socket.end(); // Close after test
      log.info(`✅ Proxy WORKING: ${proxyUrl}`);
      return true;
    } catch (err) {
      log.error(`❌ Proxy FAILED: ${proxyUrl} - ${err.message}`);
      return false;
    }
  }
  

export async function getNextProxy() {
  let proxyList = [];
  if (config.proxy?.enable) {
    if (config.proxy.use_file && config.proxy.file_path) {
      const fileProxies = await readProxiesFromFile(config.proxy.file_path);
      proxyList = proxyList.concat(fileProxies);
    }
    if (config.proxy.list && config.proxy.list.length > 0) {
      proxyList = proxyList.concat(config.proxy.list);
    }
    if (proxyList.length === 0) {
        const errMsg = '🚨 Proxy is enabled, but no proxies are configured.';
        log.error(errMsg);
        throw new Error(errMsg);
    }
  } else {
    return null;
  }
  let proxyIndex = sharedState.currentProxyIndex || 0;
  for (let i = 0; i < proxyList.length; i++) {
    const currentIndex = (proxyIndex + i) % proxyList.length;
    const proxy = proxyList[currentIndex];
    if (!proxy?.url) {
      log.warn(`⚠️ Skipping invalid proxy entry: ${JSON.stringify(proxy)}`);
      continue;
    }
    let formattedProxyUrl;
    try {
      const parsedUrl = new URL(proxy.url);
      let auth = '';
      if (proxy.username && proxy.password) {
        auth = `${proxy.username}:${proxy.password}@`;
      }
      formattedProxyUrl = `socks5://${auth}${parsedUrl.hostname}:${parsedUrl.port}`;
      const isWorking = await testProxy(formattedProxyUrl);
      if (isWorking) {
        log.info(`✅ Proxy confirmed working: ${formattedProxyUrl}`);
        sharedState.currentProxyIndex = (currentIndex + 1) % proxyList.length;
        return new SocksProxyAgent(formattedProxyUrl);
      } else {
        log.error(`❌ Proxy failed test: ${formattedProxyUrl}`);
      }
    } catch (error) {
      log.error(`❌ Error processing proxy ${proxy.url}: ${error.message}`);
    }
  }
  
  const errMsg = '🚨 No working proxies available for SMTP!';
  log.error(errMsg);
  throw new Error(errMsg);
}