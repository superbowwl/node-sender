import fs from 'fs/promises';
import log from './logger.js';
import { config } from './loadConfig.js';


export function validateEmail(email) {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const isValid = emailRegex.test(email);
  if (!isValid) log.warn(`Invalid email found and ignored: ${email}`);
  return isValid;
}

export async function readRecipients(file = config.email?.recipient_file || 'leads.csv') {
  const recipients = [];
  let lineNumber = 0;
  try {
    const data = await fs.readFile(file, 'utf8');
    const lines = data.split('\n').map(line => line.trim()).filter(line => line);
    for (const line of lines) {
      lineNumber++;
      const parts = line.split(',').map(item => item.trim());
      const email = parts[1] || parts[0];
      if (!email || !validateEmail(email)) {
        log.warn(`⚠️ Invalid email at line ${lineNumber}: ${email}`);
        continue;
      }
      recipients.push({
        name: parts[0] || '{DOMAINEMAIL}',
        email,
        company: parts[2] || '{USERNAME}',
        lineNumber,
        source: file.endsWith('.csv') ? 'CSV' : 'TXT',
      });
    }
  } catch (error) {
    log.error(`❌ Error reading recipients from ${file}: ${error.message}`);
  }
  return recipients;
}

export function filterDuplicates(recipients, config) {
  const skipDuplicates = config.email?.skipDuplicates ?? 1;
  const seenRecipients = new Set();
  let duplicateCount = 0;
  if (skipDuplicates) {
    const filteredRecipients = recipients.filter(recipient => {
      if (seenRecipients.has(recipient.email)) {
        duplicateCount++;
        return false;
      }
      seenRecipients.add(recipient.email);
      return true;
    });
    if (duplicateCount > 0) {
      log.warn(`⚠ Found ${duplicateCount} duplicate email${duplicateCount === 1 ? '' : 's'} skipped.`);
    }
    return filteredRecipients;
  }
  log.info('Duplicate skipping disabled. All recipients will be processed, including duplicates.');
  return recipients;
}