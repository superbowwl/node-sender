// ews.js
import { promises as fs } from 'fs';
import { spawn } from 'child_process';
import { Mutex } from 'async-mutex';
import log   from './logger.js';
import { config } from './loadConfig.js';
import path     from 'path'; 
import { fileURLToPath } from 'url';    
import readline from 'readline';

const ewsFile = config.Ews_Config.ews_file;
let   accounts = [];          // runtime list
let   curIdx   = 0;
const lock     = new Mutex();

const __dirname = path.dirname(import.meta.url ? fileURLToPath(import.meta.url) : __filename);
const script = path.resolve(__dirname, 'send_ews.py');
const WORKER_COUNT = config.Ews_Config.concurrency || 1;

// Spawn the pool once
const workers = Array.from({ length: WORKER_COUNT }, () => {
    const w = spawn('python', ['-u', script], { stdio: ['pipe','pipe','inherit'] });
    // attach a readline interface to w.stdout
    w._rl = readline.createInterface({ input: w.stdout });
    return w;
  });
  
  // Round-robin index
  let nextWorker = 0;


/* -------- load accounts ---------- */
export async function loadEwsAccounts() {
  const rows = (await fs.readFile(ewsFile,'utf8'))
               .split('\n').filter(l=>l && !l.startsWith('#'));
  accounts = rows.map(r=>{
    const [user, pass, endpoint, defFrom] = r.split('|');
    return { user, pass, endpoint,
             from: defFrom || user,
             limit: config.Ews_Config.limit,
             counter: 0 };
  });
  curIdx = 0;
}

/* -------- select account ---------- */
export async function getNextEws() {
  const mode = config.Ews_Config.selection_mode ?? 1;
  return lock.runExclusive(() => {
    // sequential first: try current index without advancing
    if (mode === 2) {
      const a = accounts[curIdx];
      if (a.limit === 0 || a.counter < a.limit) {
        a.counter++; return a;
      }
      curIdx = (curIdx + 1) % accounts.length;   // move once
    }
    // round-robin search
    for (let i=0;i<accounts.length;i++) {
      const idx = (curIdx + i) % accounts.length;
      const a   = accounts[idx];
      if (a.limit === 0 || a.counter < a.limit) {
        a.counter++;
        curIdx = mode === 1 ? (idx+1)%accounts.length : idx;
        return a;
      }
    }
    throw new Error('All EWS accounts have reached their email sending limit');
  });
}

/* -------- send via child-process ---------- */
export function sendViaEws(job, acc) {
    return new Promise((resolve, reject) => {
        const worker = workers[nextWorker];
        nextWorker = (nextWorker + 1) % WORKER_COUNT;
     const payload = {
        user:        acc.user,
        password:    acc.pass,
        endpoint:    acc.endpoint,
        to:          job.to,
        from:        job.from,
        subject:     job.subject,
        html:        job.html,
        importance:  job.importance,
        sensitivity: job.sensitivity,
        attachments: job.attachments || [],
      };
      function onLine(line) {
        // Once we get a line, remove listener so we don’t leak
        worker._rl.removeListener('line', onLine);
  
        let res;
        try {
          res = JSON.parse(line);
        } catch (err) {
          return reject(new Error('Invalid JSON from EWS worker: ' + err.message));
        }
        if (res.ok) return resolve(res);
        return reject(new Error(res.err || 'Unknown error'));
      }
 // Listen for exactly one response line
 worker._rl.on('line', onLine);

 // Fire off the job
 worker.stdin.write(JSON.stringify(payload) + '\n');
});
}